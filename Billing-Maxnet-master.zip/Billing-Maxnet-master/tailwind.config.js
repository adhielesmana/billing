/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./resources/**/*.blade.php",
    "./resources/**/*.js",
    "./resources/**/*.vue",
  ],
  theme: {
    extend: {
      'primary': {
        '50': '#faf5ff',
        '100': '#f4e7ff',
        '200': '#ead4ff',
        '300': '#dab2ff',
        '400': '#c481ff',
        '500': '#ad51fb',
        '600': '#992fee',
        '700': '#841ed2',
        '800': '#6f1eab',
        '900': '#5b1a89',
        '950': '#4b067b',
    },
    },
  },
  plugins: [],
}