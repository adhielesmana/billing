@extends('layouts.main')

@push('styles')
    <link rel="stylesheet" href="{{ asset('/css/flowbite.css') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />

    <style>
        #map {
            height: 400px;
            z-index: 0;
        }
    </style>
@endpush

@section('content')
@dump($errors)
    <div class="grid col-span-1 m-4">

        <div class="p-4 bg-white rounded-md shadow-lg w-full overflow-x-auto">
            <p class="mb-6 text-lg font-medium text-slate-500 tracking-wider">Form Entry Subscription</p>
            @if (session('success'))
                <div id="alert-3" class="flex p-4 mb-4 text-green-800 border-2 border-green-300 rounded-lg bg-green-50 "
                    role="alert">
                    <svg aria-hidden="true" class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd"
                            d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                            clip-rule="evenodd"></path>
                    </svg>
                    <span class="sr-only">Info</span>
                    <div class="ml-3 text-sm font-medium">
                        {{ session('success') }}
                    </div>
                    <button type="button"
                        class="ml-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex h-8 w-8  dark:hover:bg-gray-700"
                        data-dismiss-target="#alert-3" aria-label="Close">
                        <span class="sr-only">Close</span>
                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                clip-rule="evenodd"></path>
                        </svg>
                    </button>
                </div>
            @endif
            <div class="mb-6">
                <form>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg aria-hidden="true" class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none"
                                stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                            </svg>
                        </div>
                        <input type="search" id="search" name="search"
                            class="block w-full p-4 pl-10 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 "
                            placeholder="Find based Identity Number" value="{{ request('search') }}" required>
                        <button type="submit"
                            class="text-white absolute right-2.5 bottom-2.5 bg-indigo-700 hover:bg-indigo-800 focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-indigo-600 dark:hover:bg-indigo-700 dark:focus:ring-indigo-800">Search</button>
                    </div>
                </form>
            </div>
            @if ($customerData != '')
                <form action="{{ route('storeInitSubscription') }}" method="post" enctype="multipart/form-data">
                    @csrf

                    <input type="hidden" id="customerId" name="customerId" value="{{ $customerData->customer_id }}"
                        readonly>
                    <div class="mb-6">
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-500">Customer Name</label>
                        <input type="text" id="name" name="name" aria-label="name"
                            class="bg-gray-300 border border-gray-300 text-gray-500 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 cursor-not-allowed"
                            value="{{ $customerData->customer_name }}" readonly>
                    </div>

                    <div class="mb-6">
                        <label for="telp" class="block mb-2 text-sm font-medium text-gray-500">Phone</label>
                        <input type="text" id="telp" name="telp" aria-label="telp"
                            class="bg-gray-300 border border-gray-300 text-gray-500 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 cursor-not-allowed"
                            value="{{ $customerData->customer_phone }}" readonly>
                    </div>

                    <div class="mb-6">
                        <label for="service"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('service')) text-red-500 @else text-gray-500 @endif">Service</label>
                        <select id="service" name="service"
                            class="bg-gray-50 border @if ($errors->has('service')) border-red-300 @else border-gray-300 @endif text-gray-500 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                            <option value="0">Choose Service</option>
                            @foreach ($serviceData as $service)
                                <option value="{{ $service->serv_id }}">{{ strtoupper($service->service_name) }}
                                    ({{ $service->service_speed }} Mbps)
                                    - IDR
                                    {{ $service->service_price }}/month</option>
                            @endforeach
                        </select>
                        @error('service')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    
                    <div class="mb-6">
                  
                        <input type="hidden" id="custom_price" name="custom_price"
                            class="bg-gray-50 border @if ($errors->has('custom_price')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 "
                            placeholder="Example : 200000" value="0">
                        @error('custom_price')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <div class="mb-6">
                        <input type="hidden" id="group" name="group"
                            class="bg-gray-50 border @if ($errors->has('group')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 "
                            placeholder="Example : 1" value="1">
                        @error('group')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="subscription_map"
                            class="mb-2 text-sm font-medium  @if ($errors->has('subscription_map')) text-red-500 @else text-gray-500 @endif">Installation
                            Maps</label>
                        <div id="map"></div>
                        <input type="subscription_map" id="subscription_map" name="subscription_map"
                            class="bg-gray-50 border mt-2 @if ($errors->has('subscription_map')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                            placeholder="Sesuaikan di peta" value="{{ old('subscription_map') }}" required>
                        @error('site_description')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <div class="mb-6">
                        <label for="address"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('address')) text-red-500 @else text-gray-900 @endif">Installation
                            Address</label>
                        <textarea id="address" name="address" rows="3"
                            class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border @if ($errors->has('address')) border-red-300 @else border-gray-300 @endif border-gray-300 focus:ring-blue-500 focus:border-blue-500 "
                            placeholder="Example : Jln.Jalan, Desa No.0 Kelurahan, Kecamatan, Kota">{{ old('address') }}</textarea>
                        @error('address')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <div class="mb-6">
                        <label
                            class="block mb-2 text-sm font-medium  @if ($errors->has('subscription_home')) text-red-500 @else text-gray-500 @endif"
                            for="subscription_home">Building Installation Photo</label>
                        <input
                            class="block w-full text-sm border @if ($errors->has('subscription_home')) border-red-300 @else border-gray-300 @endif rounded-lg cursor-pointer bg-gray-50"
                            id="subscription_home" type="file" name="subscription_home" required>
                        @error('subscription_home')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    
                    <div class="mb-6">
                        <input type="hidden" name="cpe_site" value="ODP-1 => ODC-1">
                    </div>

                    <button type="submit"
                        class="text-white bg-indigo-700 hover:bg-indigo-800  focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Submit</button>
                </form>
            @else
                <p class="text-center mb-6">No Result.</p>
            @endif
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
    <script defer src="{{ asset('/js/flowbite.js') }}"></script>
    <script>
        var map = L.map('map').setView(new L.LatLng('-7.574426173358837', '110.82313225972996'), 13);
        var geocoder = L.Control.Geocoder.nominatim();
        var options = {
            position: 'topright',
            drawCircle: false,
            follow: true,
            keepCurrentZoomLevel: true
        };
        var marker = L.marker([0, 0], {
            draggable: true
        });

        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap'
        }).addTo(map);
        map.locate({
            setView: true,
            maxZoom: 16
        });

        function onMapClick(e) {
            marker
                .setLatLng(e.latlng)
                .addTo(map);
            document.getElementById('subscription_map').value = `${e.latlng.lat.toFixed(6)}, ${e.latlng.lng.toFixed(6)}`;
            geocoder.reverse(e.latlng, map.options.crs.scale(map.getZoom()), function(results) {
                var address = results[0].name + ', ' + results[0].properties.address.city;
                document.getElementById('address').value = address;
            });
        }

        function onChangeInputMaps() {
            $latlong = $('#subscription_map').val().replace(",", ", ").split(", ");
            $lat = parseFloat($latlong[0]);
            $long = parseFloat($latlong[1]);

            if (marker) {
                map.removeLayer(marker);
            }

            $latlong_baru = L.latLng($lat, $long);

            map.setView(new L.LatLng($lat, $long), 18);
            marker = L.marker([$lat, $long]).addTo(map);

            geocoder.reverse($latlong_baru, map.options.crs.scale(map.getZoom()), function(results) {
                var address = results[0].name + ', ' + results[0].properties.address.city;
                document.getElementById('address').value = address;
            });
        }

        map.on('click', onMapClick);
        $('#subscription_map').on('blur', onChangeInputMaps);
    </script>
@endpush
