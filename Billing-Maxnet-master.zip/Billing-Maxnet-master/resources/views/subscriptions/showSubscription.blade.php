@extends('layouts.main')

@push('styles')
    <link rel="stylesheet" href="{{ asset('/css/flowbite.css') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />

    <style>
        #map {
            height: 350px;
            z-index: 0;
        }
    </style>
@endpush

@section('content')
    @if (session('success'))
        <div id="alert-3" class="flex mx-4 p-4 mb-4 text-green-800 border-2 border-green-300 rounded-lg bg-green-50 "
            role="alert">
            <svg aria-hidden="true" class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                    clip-rule="evenodd"></path>
            </svg>
            <span class="sr-only">Info</span>
            <div class="ml-3 text-sm font-medium">
                {{ session('success') }}
            </div>
            <button type="button"
                class="ml-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex h-8 w-8"
                data-dismiss-target="#alert-3" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clip-rule="evenodd"></path>
                </svg>
            </button>
        </div>
    @endif


    <div class="grid m-4 gap-4 md:grid-cols-3">
        <div class="p-4 bg-white rounded-md shadow-lg md:col-span-1">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Customer</p>
            <div class="grid gap-4 mt-4 md:grid-cols-1">
                <div>
                    <span class="text-md text-slate-500">Name</span>
                    <p>{{ $data->customer->customer_name }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Identity Number</span>
                    <p>{{ $data->customer->customer_ktp_no }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Phone</span>
                    <p>{{ $data->customer->customer_phone }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Email</span>
                    <p>{{ $data->customer->customer_email }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Address</span>
                    <p>{{ $data->customer->customer_address }}</p>
                </div>

            </div>
        </div>
        <div class="p-4 bg-white rounded-md shadow-lg md:col-span-2">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Subscription</p>
            <hr class="mt-2">
            <div class="grid gap-4 mt-4">
                <div>
                    <span class="text-md text-slate-500">Subscription ID</span>
                    <p>Rp.{{ $data->subscription_id ?? ' -' }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Service</span>
                    <p>Paket {{ $data->service->service_name }} ({{ $data->service->service_speed }} Mbps) -
                        Rp.{{ $data->service->service_price }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Custom Price</span>
                    <p>Rp.{{ $data->subscription_price ?? ' -' }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Start Date</span>
                    <p>{{ $data->subscription_start_date ?? '-' }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Group</span>
                    <p>{{ $data->group }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Installation Maps</span>
                    <p id="data-map">{{ $data->subscription_maps ?? '-' }}</p>
                    <div id="map" value="{{ $data->subscription_maps }}"></div>
                </div>

                <div class="text-indigo-500 cursor-pointer" target=”_blank”>
                    <span class="text-md text-slate-500">Identity Number (Picture)</span>
                    <img src="{{ env('APP_URL') . '/storage/ktp/' . $data->customer->customer_ktp_picture }}"></img>
                </div>
                <div>
                    <span class="text-md text-slate-500">Installation Address</span>
                    <p>{{ $data->subscription_address }}</p>
                </div>
                <div class="flex flex-col">
                    <span class="text-md text-slate-500">Home Photo</span>
                    <img src="{{ env('APP_URL') . '/storage/sub_home/' . $data->subscription_home_photo }}"
                        class="text-indigo-500" target="_blank"></i>
                </div>
                <div class="flex flex-col">
                    <span class="text-md text-slate-500">Form Scan</span>
                    <img src="{{ env('APP_URL') . '/storage/sub_form/' . $data->subscription_form_scan }}"
                        class="text-indigo-500" target="_blank"></img>
                </div>
                <div>
                    <span class="text-md text-slate-500">CPE Serial</span>
                    <p>{{ $data->cpe_serial ?? ' -' }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">CPE Type</span>
                    <p>{{ $data->cpe_type ?? ' -' }}</p>
                </div>
                <div class="flex flex-col">
                    <span class="text-md text-slate-500">CPE Picture</span>
                    <img src="{{ env('APP_URL') . '/storage/sub_cpe/' . $data->cpe_picture }}" class="text-indigo-500"
                        target="_blank"></img>
                </div>
                <div>
                    <span class="text-md text-slate-500">CPE Site</span>
                    <p>{{ $data->cpe_site ?? ' -' }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Created at</span>
                    <p>{{ $data->created_at ?? ' -' }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Updated at</span>
                    <p>{{ $data->updated_at ?? ' -' }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Status</span>
                    <p>{{ $data->subscription_status }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Description</span>
                    <p>{{ $data->subscription_description ?? '-' }}</p>
                </div>
                <div class="flex gap-2">
                    @if ($data->subscription_status == 'NEW REQUEST')
                        <button data-modal-target="modal-proceed" data-modal-toggle="modal-proceed"
                            class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
                            type="button">
                            Proceed
                        </button>

                        <div id="modal-proceed" tabindex="-1"
                            class="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
                            <div class="relative w-full max-w-md max-h-full">
                                <div class="relative bg-white rounded-lg shadow d">
                                    <button type="button"
                                        class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center"
                                        data-modal-hide="modal-proceed">
                                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                            fill="none" viewBox="0 0 14 14">
                                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                        </svg>
                                        <span class="sr-only">Close modal</span>
                                    </button>
                                    <div class="p-6 text-center flex flex-col justify-center items-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60"
                                            viewBox="0 0 24 24"
                                            style="fill: rgba(107, 114, 128, 1);transform: ;msFilter:;">
                                            <path
                                                d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z">
                                            </path>
                                            <path
                                                d="M9.999 13.587 7.7 11.292l-1.412 1.416 3.713 3.705 6.706-6.706-1.414-1.414z">
                                            </path>
                                        </svg>
                                        <h3 class="mb-5 text-lg font-normal text-gray-500 d">Process this customer?</h3>
                                        <div class="flex justify-center">
                                            <div>
                                                <button data-modal-hide="modal-proceed" type="button"
                                                    onclick="event.preventDefault(); document.getElementById('form-proceed').submit();"
                                                    class="text-white bg-blue-500 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300  font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2">
                                                    Yes, I'm sure
                                                </button>
                                                <form id="form-proceed"
                                                    action="{{ route('proceedSubscription', ['id' => $data->subscription_id]) }}"
                                                    method="post" enctype="multipart/form-data">
                                                    @csrf
                                                    @method('PATCH')
                                                </form>
                                            </div>


                                            <button data-modal-hide="modal-proceed" type="button"
                                                class="text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10">No,
                                                cancel</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button data-modal-target="modal-decline" data-modal-toggle="modal-decline"
                            class="text-white bg-red-500 hover:bg-red-800  focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Cancel</button>
                        <div id="modal-decline" tabindex="-1"
                            class="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
                            <div class="relative w-full max-w-md max-h-full">
                                <div class="relative bg-white rounded-lg shadow d">
                                    <button type="button"
                                        class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center"
                                        data-modal-hide="modal-decline">
                                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                            fill="none" viewBox="0 0 14 14">
                                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                        </svg>
                                        <span class="sr-only">Close modal</span>
                                    </button>
                                    <div class="p-6 text-center flex flex-col justify-center items-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60"
                                            viewBox="0 0 24 24"
                                            style="fill: rgba(107, 114, 128, 1);transform: ;msFilter:;">
                                            <path
                                                d="M20.5 5A1.5 1.5 0 0 0 19 6.5V11h-1V4.5a1.5 1.5 0 0 0-3 0V11h-1V3.5a1.5 1.5 0 0 0-3 0V11h-1V5.5a1.5 1.5 0 0 0-3 0v10.81l-2.22-3.6a1.5 1.5 0 0 0-2.56 1.58l3.31 5.34A5 5 0 0 0 9.78 22H17a5 5 0 0 0 5-5V6.5A1.5 1.5 0 0 0 20.5 5z">
                                            </path>
                                        </svg>
                                        <h3 class="mb-5 text-lg font-normal text-gray-500 d">Decline this customer?</h3>
                                        <div class="flex justify-center">
                                            <div>
                                                <button data-modal-hide="modal-decline" type="button"
                                                    onclick="event.preventDefault(); document.getElementById('form-decline').submit();"
                                                    class="text-white bg-red-500 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300  font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2">
                                                    Yes, I'm sure
                                                </button>
                                                <form id="form-decline"
                                                    action="{{ route('declineSubscription', ['id' => $data->subscription_id]) }}"
                                                    method="post" enctype="multipart/form-data">
                                                    @csrf
                                                    @method('PATCH')
                                                </form>
                                            </div>


                                            <button data-modal-hide="modal-decline" type="button"
                                                class="text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10">No,
                                                wait</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif

                    @if ($data->subscription_status == 'INSTALLED')
                        <button data-modal-target="modal-activate" data-modal-toggle="modal-activate"
                            class="text-white bg-green-500 hover:bg-green-800  focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Activate</button>
                        <div id="modal-activate" tabindex="-1"
                            class="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
                            <div class="relative w-full max-w-md max-h-full">
                                <div class="relative bg-white rounded-lg shadow d">
                                    <button type="button"
                                        class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center"
                                        data-modal-hide="modal-activate">
                                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                            fill="none" viewBox="0 0 14 14">
                                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                        </svg>
                                        <span class="sr-only">Close modal</span>
                                    </button>
                                    <div class="p-6 text-center flex flex-col justify-center items-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60"
                                            viewBox="0 0 24 24"
                                            style="fill: rgba(107, 114, 128, 1);transform: ;msFilter:;">
                                            <path
                                                d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z">
                                            </path>
                                            <path
                                                d="M9.999 13.587 7.7 11.292l-1.412 1.416 3.713 3.705 6.706-6.706-1.414-1.414z">
                                            </path>
                                        </svg>
                                        <h3 class="mb-5 text-lg font-normal text-gray-500 d">Activate this customer?</h3>
                                        <div class="flex justify-center">
                                            <div>
                                                <button data-modal-hide="modal-activate" type="button"
                                                    onclick="event.preventDefault(); document.getElementById('form-activate').submit();"
                                                    class="text-white bg-green-500 hover:bg-green-800 focus:ring-4 focus:outline-none focus:ring-green-300  font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2">
                                                    Yes, I'm sure
                                                </button>
                                                <form id="form-activate"
                                                    action="{{ route('activateSubscription', ['id' => $data->subscription_id]) }}"
                                                    method="post" enctype="multipart/form-data">
                                                    @csrf
                                                    @method('PATCH')
                                                </form>
                                            </div>


                                            <button data-modal-hide="modal-activate" type="button"
                                                class="text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10">No,
                                                wait</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script>
        var map = L.map('map').fitWorld();

        var dataMaps = $('#data-map').text();
        var data = dataMaps.split(",");

        if (dataMaps) {
            L.marker([data[0], data[1]]).addTo(map);
            map.setView(new L.LatLng(data[0], data[1]), 16);
        } else {
            map.setView(new L.LatLng('-4.249029', '-236.590369'), 4);
        }

        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap'
        }).addTo(map);

        var options = {
            position: 'topright', // Change the position of the control
            drawCircle: false, // Disable the accuracy circle
            follow: true, // Automatically follow the user's location
            keepCurrentZoomLevel: true // Maintain the current zoom level
        };
    </script>
    <script defer src="{{ asset('/js/flowbite.js') }}"></script>
@endpush
