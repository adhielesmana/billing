@extends('layouts.main')

@push('styles')
    <link rel="stylesheet" href="{{ asset('/css/flowbite.css') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />

    <style>
        #map {
            height: 250px;
            z-index: 0;
        }
    </style>
@endpush

@section('content')
    <div class="grid m-4 gap-4">
        <div class="p-4 bg-white rounded-md shadow-lg md:col-span-2">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Edit Subscription</p>
            <hr class="mt-2">
            <div class="grid gap-4 mt-4 overflow-x-auto">
                <form action="{{ route('updateSubscription', ['id' => $data->subscription_id]) }}" method="post"
                    enctype="multipart/form-data">
                    @csrf
                    @method('PATCH')
                    <div class="mb-4">
                        <label for="service"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('service')) text-red-500 @else text-gray-900 @endif">Service</label>
                        <select id="service" name="service"
                            class="bg-gray-50 border @if ($errors->has('service')) border-red-300 @else border-gray-300 @endif text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                            <option>Choose Service</option>
                            @foreach ($serviceData as $service)
                                <option value="{{ $service->serv_id }}"
                                    {{ $service->serv_id == $data->service->serv_id ? 'selected' : '' }}>
                                    {{ strtoupper($service->service_name) }}
                                    ({{ $service->service_speed }} Mbps)
                                    - IDR
                                    {{ $service->service_price }}/month</option>
                            @endforeach
                        </select>
                        @error('service')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-4">
                        <label for="price"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('price')) text-red-500 @else text-gray-500 @endif">Custom
                            Price</label>
                        <input type="number" id="price" name="price"
                            class="bg-gray-50 border @if ($errors->has('price')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                            placeholder="Custom Price" value="{{ old('price', $data->subscription_price) }}">
                        @error('price')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-4">
                        <label for="group"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('group')) text-red-500 @else text-gray-500 @endif">Group</label>
                        <input type="text" id="group" name="group"
                            class="bg-gray-50 border @if ($errors->has('group')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                            placeholder="Group" value="{{ old('group', $data->group) }}" required>
                        @error('group')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-4">
                        <label for="address"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('address')) text-red-500 @else text-gray-900 @endif">Installation
                            Address</label>
                        <textarea id="address" name="address" rows="3"
                            class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border @if ($errors->has('address')) border-red-300 @else border-gray-300 @endif border-gray-300 focus:ring-blue-500 focus:border-blue-500 "
                            placeholder="Example : Jln.Jalan, Desa No.0 Kelurahan, Kecamatan, Kota">{{ old('address', $data->subscription_address) }}</textarea>
                        @error('address')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-4">
                        <label for="subscription_map"
                            class="mb-2 text-sm font-medium  @if ($errors->has('subscription_map')) text-red-500 @else text-gray-500 @endif">Installation
                            Maps</label>
                        <div id="map"></div>
                        <input type="subscription_map" id="subscription_map" name="subscription_map"
                            class="bg-gray-50 border mt-2 @if ($errors->has('subscription_map')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                            placeholder="Sesuaikan di peta" value="{{ old('address', $data->subscription_maps) }}">
                        @error('site_description')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-4">
                        <label
                            class="block mb-2 text-sm font-medium  @if ($errors->has('subscription_home')) text-red-500 @else text-gray-500 @endif"
                            for="subscription_home">Building Installation Photo</label>
                        <input
                            class="block w-full text-sm border @if ($errors->has('subscription_home')) border-red-300 @else border-gray-300 @endif rounded-lg cursor-pointer bg-gray-50"
                            id="subscription_home" type="file" name="subscription_home">
                        @error('subscription_home')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-4">
                        <label
                            class="block mb-2 text-sm font-medium  @if ($errors->has('subscription_form')) text-red-500 @else text-gray-500 @endif"
                            for="foto-ktp">Form Scan</label>
                        <input
                            class="block w-full text-sm border @if ($errors->has('subscription_form')) border-red-300 @else border-gray-300 @endif rounded-lg cursor-pointer bg-gray-50"
                            id="foto-ktp" type="file" name="subscription_form">
                        @error('subscription_form')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-4">
                        <label for="cpe_serial"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('cpe_serial')) text-red-500 @else text-gray-500 @endif">CPE
                            Serial</label>
                        <input type="text" id="cpe_serial" name="cpe_serial"
                            class="bg-gray-50 border @if ($errors->has('cpe_serial')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                            placeholder="Example : SHRK-920-DED-SKLIE" value="{{ old('address', $data->cpe_serial) }}">
                        @error('cpe_serial')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-4">
                        <label
                            class="block mb-2 text-sm font-medium  @if ($errors->has('cpe_picture')) text-red-500 @else text-gray-500 @endif"
                            for="cpe_picture">CPE Picture</label>
                        <input
                            class="block w-full text-sm border @if ($errors->has('cpe_picture')) border-red-300 @else border-gray-300 @endif rounded-lg cursor-pointer bg-gray-50"
                            id="cpe_picture" type="file" name="cpe_picture">
                        @error('cpe_picture')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="cpe_site"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('cpe_site')) text-red-500 @else text-gray-500 @endif">CPE
                            Site</label>
                        <select id="cpe_site" name="cpe_site"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                            <option value="">Choose Site</option>
                            <option value="ILT">ILT</option>
                            <option value="ODC">ODC</option>
                            <option value="ODP">ODP</option>
                            {{-- @foreach ($serviceData as $service)
                            <option value="{{ $service->serv_id }}">{{ $service->service_name }} - Rp
                                {{ $service->service_price }}/bulan</option>
                        @endforeach --}}
                        </select>
                    </div>

                    <div class="mb-4">
                        <label for="cpe_type"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('cpe_type')) text-red-500 @else text-gray-500 @endif">CPE
                            Type</label>
                        <input type="text" id="cpe_type" name="cpe_type"
                            class="bg-gray-50 border @if ($errors->has('cpe_type')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 "
                            placeholder="Example : ODP" value="{{ old('address', $data->cpe_type) }}">
                        @error('cpe_type')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <button type="submit"
                        class="text-white bg-indigo-700 hover:bg-indigo-800  focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Update</button>
                </form>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
    <script defer src="{{ asset('/js/flowbite.js') }}"></script>
    <script>
        var map = L.map('map').fitWorld();
        var dataMaps = $('#subscription_map').val();
        var data = dataMaps.split(",");

        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap'
        }).addTo(map);

        map.locate({
            setView: true,
            maxZoom: 16
        });

        var options = {
            position: 'topright', // Change the position of the control
            drawCircle: false, // Disable the accuracy circle
            follow: true, // Automatically follow the user's location
            keepCurrentZoomLevel: true // Maintain the current zoom level
        };

        if (dataMaps) {
            marker = L.marker([data[0], data[1]]).addTo(map);
            map.setView(new L.LatLng(data[0], data[1]), 16);
        } else {
            map.setView(new L.LatLng('-4.249029', '-236.590369'), 4);
        }

        function onMapClick(e) {
            marker.remove();
            marker
                .setLatLng(e.latlng)
                .addTo(map);
            document.getElementById('subscription_map').value = `${e.latlng.lat.toFixed(6)},${e.latlng.lng.toFixed(6)}`;
            geocoder.reverse(e.latlng, map.options.crs.scale(map.getZoom()), function(results) {
                var address = results[0].name + ', ' + results[0].properties.address.city;
                document.getElementById('address').value = address;
            });
        }

        function onChangeInputMaps() {
            $latlong = $('#subscription_map').val().replace(",", ", ").split(", ");
            $lat = parseFloat($latlong[0]);
            $long = parseFloat($latlong[1]);

            if (marker) {
                map.removeLayer(marker);
            }

            $latlong_baru = L.latLng($lat, $long);

            map.setView(new L.LatLng($lat, $long), 18);
            marker = L.marker([$lat, $long]).addTo(map);

            geocoder.reverse($latlong_baru, map.options.crs.scale(map.getZoom()), function(results) {
                var address = results[0].name + ', ' + results[0].properties.address.city;
                document.getElementById('address').value = address;
            });
        }

        map.on('click', onMapClick);
        $('#subscription_map').on('change', onChangeInputMaps);
    </script>
@endpush
