@extends('layouts.main')

@push('styles')
    <link rel="stylesheet" href="{{ asset('/css/flowbite.css') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />

    <style>
        #map {
            height: 300px;
            z-index: 0;
        }
    </style>
@endpush

@section('content')
    @if (session('success'))
        <div id="alert-3" class="flex mx-4 p-4 mb-4 text-green-800 border-2 border-green-300 rounded-lg bg-green-50 "
            role="alert">
            <svg aria-hidden="true" class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                    clip-rule="evenodd"></path>
            </svg>
            <span class="sr-only">Info</span>
            <div class="ml-3 text-sm font-medium">
                {{ session('success') }}
            </div>
            <button type="button"
                class="ml-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex h-8 w-8"
                data-dismiss-target="#alert-3" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clip-rule="evenodd"></path>
                </svg>
            </button>
        </div>
    @endif


    <div class="grid m-4 gap-4 md:grid-cols-3">
        <div class="p-4 bg-white rounded-md shadow-lg md:col-span-1">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Subscription</p>
            <div class="grid gap-4 mt-4 overflow-x-auto">
                <div>
                    <span class="text-md text-slate-500">Name</span>
                    <p>{{ $data->customer->customer_name }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Phone</span>
                    <p>{{ $data->customer->customer_phone }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Installation Maps</span>
                    <p id="data-map">{{ $data->subscription_maps ?? '-' }}</p>
                    <div id="map"></div>
                </div>
                <div>
                    <span class="text-md text-slate-500">Installation Address</span>
                    <p>{{ $data->subscription_address }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Service</span>
                    <p>Paket {{ $data->service->service_name }} ({{ $data->service->service_speed }} Mbps) -
                        Rp.{{ $data->service->service_price }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Status</span>
                    <p>{{ $data->subscription_status }}</p>
                </div>
            </div>
        </div>
        <div class="p-4 bg-white rounded-md shadow-lg md:col-span-2">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Entry Technician</p>
            <hr class="mt-2">
            <div class="grid gap-4 mt-4">
                <form action="{{ route('updateTechSubscription', ['id' => $data->subscription_id]) }}" method="post"
                    enctype="multipart/form-data">
                    @csrf
                    @method('PATCH')
                    <div class="mb-4">
                        <label
                            class="block mb-2 text-sm font-medium  @if ($errors->has('subscription_form')) text-red-500 @else text-gray-500 @endif"
                            for="foto-ktp">Form Scan</label>
                        <input
                            class="block w-full text-sm border @if ($errors->has('subscription_form')) border-red-300 @else border-gray-300 @endif rounded-lg cursor-pointer bg-gray-50"
                            id="foto-ktp" type="file" name="subscription_form" required>
                        @error('subscription_form')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-4">
                        <label for="cpe_serial"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('cpe_serial')) text-red-500 @else text-gray-500 @endif">CPE
                            Serial Number</label>
                        <input type="text" id="cpe_serial" name="cpe_serial"
                            class="bg-gray-50 border @if ($errors->has('cpe_serial')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                            placeholder="Example : SHRK-920-DED-SKLIE" value="{{ old('cpe_serial') }}" required>
                        @error('cpe_serial')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-4">
                        <label
                            class="block mb-2 text-sm font-medium  @if ($errors->has('cpe_picture')) text-red-500 @else text-gray-500 @endif"
                            for="cpe_picture">CPE Picture</label>
                        <input
                            class="block w-full text-sm border @if ($errors->has('cpe_picture')) border-red-300 @else border-gray-300 @endif rounded-lg cursor-pointer bg-gray-50"
                            id="cpe_picture" type="file" name="cpe_picture" required>
                        @error('cpe_picture')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="cpe_type"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('cpe_type')) text-red-500 @else text-gray-500 @endif">CPE
                            / Modem Type</label>
                        <input type="text" id="cpe_type" name="cpe_type"
                            class="bg-gray-50 border @if ($errors->has('cpe_type')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 "
                            placeholder="Example : ZTE F660" value="{{ old('cpe_type') }}">
                        @error('cpe_type')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <button type="submit"
                        class="text-white bg-indigo-700 hover:bg-indigo-800  focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Submit</button>
                </form>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script defer src="{{ asset('/js/flowbite.js') }}"></script>
    <script>
        var map = L.map('map').setView(new L.LatLng('-7.574426173358837', '110.82313225972996'), 13);
        var options = {
            position: 'topright',
            drawCircle: false,
            follow: true,
            keepCurrentZoomLevel: true
        };
        var dataMaps = $('#data-map').text();
        var data = dataMaps.split(",");

        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap'
        }).addTo(map);

        if (dataMaps) {
            console.log(dataMaps);
            L.marker([data[0], data[1]]).addTo(map);
            map.setView(new L.LatLng(data[0], data[1]), 16);
        } else {
            map.setView(new L.LatLng('-4.249029', '-236.590369'), 4);
        }
    </script>
@endpush
