<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" type="image/x-icon" href="{{ asset('storage/logo.png') }}">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Roboto&display=swap"
        rel="stylesheet" />
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/flowbite.css') }}" rel="stylesheet">
    <title>Sign in</title>
</head>

<body class="">
    @if ($errors->has('invalid'))
        <section class="bg-gray-50 ">
            <div class="flex flex-col items-center justify-center px-6 py-4 mx-auto md:h-screen lg:py-0">
                <a href="#" class="flex items-center mb-6 text-2xl font-semibold text-gray-900 ">
                    <img class="h-[4rem] mr-2" src="{{ asset('storage/icon.png') }}" alt="logo">
                </a>
                <div class="w-full bg-white rounded-lg shadow-md md:mt-0 sm:max-w-md xl:p-0 p-4 flex flex-col gap-4">
                    <span class="font-bold text-2xl mx-auto">{{ $errors->first('invalid') }}</span>
                    <span class="font-bold text-1xl mx-auto">Silahkan Login Kembali</span>
                    <a href="{{ route('login') }}"
                        class="mx-auto text-white w-[200px] bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-md text-sm px-5 py-2.5 text-center ">Sign
                        in</a>
                </div>
            </div>
        </section>
    @else
        <section class="bg-gray-50 ">
            <div class="flex flex-col items-center px-6 py-8 mx-auto lg:py-0">
                <a href="#" class="flex items-center mb-6 text-2xl font-semibold text-gray-900">
                    <img class="h-[4rem] mr-2" src="{{ asset('storage/icon.png') }}" alt="logo">

                </a>
                <div class="w-full bg-white rounded-lg shadow-md md:mt-0 sm:max-w-md xl:p-0 ">
                    <div class="p-6 md:space-y-6 sm:p-8 ">
                        <div class="flex items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                                <path d="m13 16 5-4-5-4v3H4v2h9z"></path>
                                <path
                                    d="M20 3h-9c-1.103 0-2 .897-2 2v4h2V5h9v14h-9v-4H9v4c0 1.103.897 2 2 2h9c1.103 0 2-.897 2-2V5c0-1.103-.897-2-2-2z">
                                </path>
                            </svg>
                            <h1 class="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl mx-4">
                                Register User
                            </h1>

                        </div>

                        <div class="p-4 mb-4 text-sm text-blue-800 rounded-lg bg-blue-50" role="alert">
                            <span class="font-medium">Selamat anda telah menjadi bagian dari kami,</span> Mohon untuk
                            mencatat username dan password anda.
                        </div>
                        <form class="space-y-4 md:space-y-6" action="{{ route('registered') }}" method="POST">
                            @csrf
                            @method('PATCH')
                            <input type="hidden" name="id" value="{{ $user->user_id }}">
                            <div>
                                <label
                                    class="block mb-2 text-sm font-medium @if ($errors->has('email')) text-red-500 @else text-gray-900 @endif">Email
                                    (Mohon diganti jika email anda salah)</label>
                                <input type="text" name="email"
                                    class="bg-gray-100 border @if ($errors->has('email')) border-red-300 @else border-gray-300 @endif text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                    value="{{ old('email', $user->email) }}">
                                @error('email')
                                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                            class="font-medium">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <label for="fullname"
                                    class="block mb-2 text-sm font-medium @if ($errors->has('fullname')) text-red-500 @else text-gray-900 @endif ">Nama
                                    Panjang</label>
                                <input type="text" name="fullname" id="fullname"
                                    class="bg-gray-50 border @if ($errors->has('fullname')) border-red-300 @else border-gray-300 @endif text-gray-900 sm:text-sm rounded-lg focus:ring-indigo-600 focus:border-indigo-600 block w-full p-2.5 d "
                                    placeholder="fullname" value="{{ old('fullname') }}" required>
                                @error('fullname')
                                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                            class="font-medium">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <label for="username"
                                    class="block mb-2 text-sm font-medium @if ($errors->has('username')) text-red-500 @else text-gray-900 @endif ">Username</label>
                                <input type="text" name="username" id="username"
                                    class="bg-gray-50 border @if ($errors->has('username')) border-red-300 @else border-gray-300 @endif text-gray-900 sm:text-sm rounded-lg focus:ring-indigo-600 focus:border-indigo-600 block w-full p-2.5 d "
                                    placeholder="username" value="{{ old('username') }}" required>
                                @error('username')
                                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                            class="font-medium">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <label for="password"
                                    class="block mb-2 text-sm font-medium @if ($errors->has('password')) text-red-500 @else text-gray-900 @endif ">Password</label>
                                <input type="password" name="password" id="password" placeholder="••••••••"
                                    class="bg-gray-50 border @if ($errors->has('password')) border-red-300 @else border-gray-300 @endif text-gray-900 sm:text-sm rounded-lg focus:ring-indigo-600 focus:border-indigo-600 block w-full p-2.5 "
                                    required>
                                @error('password')
                                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                            class="font-medium">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <label for="password_confirmation"
                                    class="block mb-2 text-sm font-medium @if ($errors->has('password_confirmation')) text-red-500 @else text-gray-900 @endif ">Ulangi
                                    Password</label>
                                <input type="password" name="password_confirmation" id="password_confirmation"
                                    placeholder="••••••••"
                                    class="bg-gray-50 border @if ($errors->has('password_confirmation')) border-red-300 @else border-gray-300 @endif text-gray-900 sm:text-sm rounded-lg focus:ring-indigo-600 focus:border-indigo-600 block w-full p-2.5 "
                                    required>
                                @error('password_confirmation')
                                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                            class="font-medium">{{ $message }}</p>
                                @enderror
                            </div>
                            <button type="submit"
                                class="w-full text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center ">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    @endif

    <script src="{{ asset('js/flowbite.js') }}"></script>
</body>

</html>
