@extends('layouts.main')

@section('content')
    <div class="grid col-span-1 m-4">
        <div class="p-4 bg-white rounded-md shadow-lg w-full overflow-x-auto">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Edit User</p>
            <div class="flex justify-end">
                <a href="{{ route('customer') }}" class="bg-indigo-500 text-white px-4 py-2 rounded-md">Kembali</a>
            </div>
            <form action="{{ route('updateUser', ['id' => $user->user_id]) }}" method="post">
                @csrf
                @method('PUT')
                <div class="mb-6">
                    <label for="full_name"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('full_name')) text-red-500 @else text-gray-500 @endif">
                        Nama Panjang</label>
                    <input type="text" id="full_name" name="full_name"
                        class="bg-gray-50 border @if ($errors->has('full_name')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="Full Name Customer" value="{{ old('full_name', $user->full_name) }}" required>
                    @error('full_name')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}</p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label for="username"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('username')) text-red-500 @else text-gray-500 @endif">
                        Username</label>
                    <input type="text" id="username" name="username"
                        class="bg-gray-50 border @if ($errors->has('username')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="Full Name Customer" value="{{ old('username', $user->username) }}" required>
                    @error('username')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}</p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label for="email"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('email')) text-red-500 @else text-gray-500 @endif">Email
                        address</label>
                    <input type="email" id="email" name="email"
                        class="bg-gray-50 border @if ($errors->has('email')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="john.doe@company.com" value="{{ old('email', $user->email) }}" required>
                    @error('email')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}</p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label for="countries" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Pilih akses
                        user</label>
                    <select id="countries" name="user_level_id"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ">
                        @foreach ($roles as $role)
                            <option value="{{ $role->user_level_id }}">{{ $role->user_level_name }}</option>
                        @endforeach
                    </select>
                </div>

                <button type="submit"
                    class="text-white bg-indigo-700 hover:bg-indigo-800  focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Submit</button>
            </form>
        </div>
    </div>
@endsection
