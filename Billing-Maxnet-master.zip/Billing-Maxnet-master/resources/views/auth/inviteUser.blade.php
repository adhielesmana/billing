@extends('layouts.main')

@section('content')
    <div class="grid grid-cols-1 m-4">
        <div class="p-4 bg-white rounded-md shadow-lg w-full overflow-x-auto">
            <p class="text-lg font-medium text-slate-500 tracking-wider mb-8">Tambahkan User</p>
            <form action="{{ route('invited') }}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="grid md:grid-cols-2 mb-6 gap-4">
                    <div>
                        <label for="email"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('email')) text-red-500 @else text-gray-500 @endif">Email
                            address</label>
                        <input type="email" id="email" name="email"
                            class="bg-gray-50 border @if ($errors->has('email')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                            placeholder="john.doe@company.com" value="{{ old('email') }}" required>
                        @error('email')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                    <div class="mb-6">
                        <label for="countries" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Pilih
                            akses user</label>
                        <select id="countries" name="user_level_id"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ">
                            @foreach ($roles as $role)
                                <option value="{{ $role->user_level_id }}">{{ $role->user_level_name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <button type="submit"
                    class="text-white bg-indigo-700 hover:bg-indigo-800  focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Submit</button>
            </form>
        </div>
    </div>
@endsection
