@cannot('isSales', auth()->user())
    <div class="flex gap-2">
        @can('isAdmin', auth()->user())
            <a class="cursor-pointer flex items-center px-2 py-1 rounded-full bg-green-500 text-white"
                href="{{ route('showSubscription', ['id' => $subscription_id]) }}"><i class='bx bx-xs bx-task'></i></a>
            <a class="cursor-pointer flex items-center px-2 py-1 rounded-full bg-yellow-400 text-white"
                href="{{ route('editSubscription', ['id' => $subscription_id]) }}"><i class='bx bx-xs bx-edit'></i></a>
        @endcan
        @can('isNoc', auth()->user())
            <a class="cursor-pointer flex items-center px-2 py-1 rounded-full bg-green-500 text-white"
                href="{{ route('showSubscription', ['id' => $subscription_id]) }}"><i class='bx bx-xs bx-task'></i></a>
            <a class="cursor-pointer flex items-center px-2 py-1 rounded-full bg-yellow-400 text-white"
                href="{{ route('editSubscription', ['id' => $subscription_id]) }}"><i class='bx bx-xs bx-edit'></i></a>
        @endcan
        @can('isTeknisi', auth()->user())
            <a class="cursor-pointer flex items-center px-2 py-1 rounded-full bg-blue-700 text-white"
                href="{{ route('entryTechSubscription', ['id' => $subscription_id]) }}"><i class='bx bx-xs bx-paste'></i></a>
        @endcan
    </div>
@endcannot
