<div class="flex gap-2">
    @can('view', App\Models\Site::find($site_id))
        <a class="cursor-pointer" href="{{ route('showSite', ['id' => $site_id]) }}"><i class='bx bx-sm bx-show-alt'></i></a>
    @endcan
    @can('update', App\Models\Site::find($site_id))
        <a class="cursor-pointer text-sky-500" href="{{ route('editSite', ['id' => $site_id]) }}"><i
                class='bx bx-sm bxs-edit-alt'></i></a>
    @endcan
    {{-- @can('delete', App\Models\Site::find($site_id))
        @include('datatables::delete', ['value' => $site_id])
    @endcan --}}
</div>
