<div class="flex gap-2">
    <a class="cursor-pointer flex items-center px-2 py-1 rounded-full bg-blue-500 text-white"
        href="{{ route('service.edit', ['id' => $serv_id]) }}"><i class='bx bx-xs bx-edit'></i></a>

    @include('datatables::delete', ['value' => $serv_id])
</div>
