<div class="flex gap-2">
    @can('view', App\Models\Customer::find($customer_id))
        <a class="cursor-pointer flex items-center px-2 py-1 rounded-full bg-green-500 text-white"
            href="{{ route('showCustomer', ['id' => $customer_id]) }}"><i class='bx bx-xs bx-show-alt'></i></a>
    @endcan
    @can('update', App\Models\Customer::find($customer_id))
        <a class="cursor-pointer flex items-center px-2 py-1 rounded-full bg-yellow-400 text-white"
            href="{{ route('editCustomer', ['id' => $customer_id]) }}"><i class='bx bx-xs bx-edit'></i></a>
    @endcan
    @can('delete', App\Models\Customer::find($customer_id))
        @include('datatables::delete', ['value' => $customer_id])
    @endcan
</div>
