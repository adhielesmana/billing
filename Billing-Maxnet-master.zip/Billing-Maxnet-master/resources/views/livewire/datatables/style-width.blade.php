@if (isset($column['width']))style="width:{{ $column['width'] }};"@endif
@if (isset($column['minWidth']))style="min-width:{{ $column['minWidth'] }};"@endif
@if (isset($column['maxWidth']))style="max-width:{{ $column['maxWidth'] }};"@endif
