<div class="flex gap-2">
    <a class="cursor-pointer" href="{{ route('showUser', ['id' => $user_id]) }}"><i class='bx bx-sm bx-show-alt'></i></a>
    <a class="cursor-pointer text-sky-500" href="{{ route('editUser', ['id' => $user_id]) }}"><i
            class='bx bx-sm bxs-edit-alt'></i></a>
    @include('datatables::delete', ['value' => $user_id])
</div>
