@extends('layouts.main')

@section('content')
    <div class="grid m-4 lg:grid-cols-4 grid-cols-2 gap-4 h-auto">
        <div class="card bg-white shadow-xl rounded-2xl p-4">
            <span>
                <p class="font-semibold">
                    Today Money
                </p>
                <p class="font-bold text-2xl">1234</p>
                <span class="flex">
                    <p><span class="text-emerald-500 font-bold">+50%</span>
                        than last month
                    </p>
                </span>
            </span>
        </div>
        <div class="card bg-white shadow-xl rounded-2xl p-4">
            <span>
                <p class="font-semibold">
                    Today Costomer
                </p>
                <p class="font-bold text-2xl">1234</p>
                <span class="flex">
                    <p><span class="text-emerald-500 font-bold">+50%</span>
                        than last month
                    </p>
                </span>
            </span>
        </div>
        <div class="card bg-white shadow-xl rounded-2xl p-4">
            <span>
                <p class="font-semibold">
                    New Client
                </p>
                <p class="font-bold text-2xl">1234</p>
                <span class="flex">
                    <p><span class="text-emerald-500 font-bold">+50%</span>
                        than last month
                    </p>
                </span>
            </span>
        </div>
        <div class="card bg-white shadow-xl rounded-2xl p-4">
            <span>
                <p class="font-semibold">
                    Sales
                </p>
                <p class="font-bold text-2xl">1234</p>
                <span class="flex">
                    <p><span class="text-emerald-500 font-bold">+50%</span>
                        than last month
                    </p>
                </span>
            </span>
        </div>
    </div>
    <div class="grid lg:grid-cols-3 lg-cols-1 gap-4 m-4">
        <div class="lg:col-span-2 h-[300px] shadow-xl rounded-md bg-white p-4 ">
            anggep ini Graph
        </div>
        <div class="h-[300px] shadow-xl rounded-md bg-white p-4">
            Ini new customer
        </div>
    </div>
    <div class="grid lg:grid-cols-2 gap-4 m-4">
        <div class="h-[300px] shadow-xl rounded-md bg-white p-4">
            Customer Paid
        </div>
        <div class="h-[300px] shadow-xl rounded-md bg-white p-4">
            ini top service
        </div>
    </div>
@endsection