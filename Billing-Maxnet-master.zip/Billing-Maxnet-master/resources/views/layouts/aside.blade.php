{{-- <div class="bg-slate-500 h-full w-full">asdasdsad</div> --}}
<div class="fixed w-[260px] bg-white h-full p-4 shadow">
    <div class="text-3xl text-indigo-500 font-semibold flex justify-between my-8">
        <img src="{{asset('storage/icon.png')}}" class="h-[50px]" alt="icon maxnet">
        <div class="my-auto" id="close-sidebar">
            <i class="bx bx-x lg:hidden"></i>
        </div>
    </div>

    <div class="text-slate-500">
        @if (Request::route()->getName() == 'home')
            <a href="{{ route('home') }}"
                class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md">
                <i class="bx bx-xs bx-home"></i>
                <span class="ml-2">Home</span>
            </a>
        @else
            <a href="{{ route('home') }}"
                class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer ">
                <i class="bx bx-xs bx-home"></i>
                <span class="ml-2">Home</span>
            </a>
        @endif

        <div class="mt-6 mb-3">
            <p>MENU LAINNYA</p>
        </div>

        @can('viewAny', App\Models\Customer::class)
            @if (Request::route()->getPrefix() == '/customer')
                <a href="{{ route('customer') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md">
                    <i class="bx bx-xs bx-user"></i>
                    <span class="ml-2">Customer</span>
                </a>
            @else
                <a href="{{ route('customer') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                    <i class="bx bx-xs bx-user"></i>
                    <span class="ml-2">Customer</span>
                </a>
            @endif
        @endcan

        @can('isSales', App\Models\User::class)
            @if (Request::route()->getPrefix() == '/customer')
                <a href="{{ route('entryCustomer') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md">
                    <i class="bx bx-xs bx-user"></i>
                    <span class="ml-2">Customer</span>
                </a>
            @else
                <a href="{{ route('entryCustomer') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                    <i class="bx bx-xs bx-user"></i>
                    <span class="ml-2">Customer</span>
                </a>
            @endif
        @endcan

        @can('isAdmin', App\Models\User::class)
            @if (Request::route()->getPrefix() == '/user')
                <a href="{{ route('user') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md">
                    <i class="bx bx-xs bx-user-circle"></i>
                    <span class="ml-2">User</span>
                </a>
            @else
                <a href="{{ route('user') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                    <i class="bx bx-xs bx-user-circle"></i>
                    <span class="ml-2">User</span>
                </a>
            @endif
        @endcan

        @cannot('isTeknisi', App\Models\User::class)
            @can('viewAny', App\Models\Subscription::class)
                @if (Request::route()->getPrefix() == '/subscription')
                    <a href="{{ route('subscription') }}"
                        class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md">
                        <i class="bx bx-xs bx-notepad"></i>
                        <span class="ml-2">Subscription</span>
                    </a>
                @else
                    <a href="{{ route('subscription') }}"
                        class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                        
                        <i class="bx bx-xs bx-notepad"></i>
                        <span class="ml-2">Subscription</span>
                    </a>
                @endif
            @endcan
        @endcannot

        @can('isTeknisi', App\Models\User::class)
            @if (Request::route()->getPrefix() == '/subscription')
                <a href="{{ route('subscription') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md">
                    <i class="bx bx-xs bx-notepad"></i>
                    <span class="ml-2">Work Order</span>
                </a>
            @else
                <a href="{{ route('subscription') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                    <i class="bx bx-xs bx-notepad"></i>
                    <span class="ml-2">Work Order</span>
                </a>
            @endif
        @endcan

        @can('viewAny', App\Models\Service::class)
            @if (Request::route()->getPrefix() == '/service')
                <a href="{{ route('service') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md">
                    <i class="bx bx-xs bx-aperture"></i>
                    <span class="ml-2">Service</span>
                </a>
            @else
                <a href="{{ route('service') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                    <i class="bx bx-xs bx-aperture"></i>
                    <span class="ml-2">Service</span>
                </a>
            @endif
        @endcan

        @can('viewAny', App\Models\Site::class)
            @if (Request::route()->getPrefix() == '/site')
                <a href="{{ route('site') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md">
                    <i class="bx bx-xs bx-broadcast"></i>
                    <span class="ml-2">Site</span>
                </a>
            @else
                <a href="{{ route('site') }}"
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                    <i class="bx bx-xs bx-broadcast"></i>
                    <span class="ml-2">Site</span>
                </a>
            @endif
        @endcan

        @if (true)
            {{-- kosong dulu --}}
        @else
            <div class="dropdown">
                <div
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md justify-between dropdown-title">
                    <span class="flex">
                        <i class="bx bx-xs bx-code-alt"></i>
                        <span class="ml-2">Dropdown</span>
                    </span>
                    <i class="bx bx-xs bx-chevron-down"></i>
                </div>
                <div class="dropdown-list hidden transition-all ease-in-out duration-300">
                    <div
                        class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                        <span class="w-[25px]"></span>
                        <span class="ml-2">List 1</span>
                    </div>
                    <div
                        class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                        <span class="w-[25px]"></span>
                        <span class="ml-2">List 2</span>
                    </div>
                    <div
                        class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md">
                        <span class="w-[25px]"></span>
                        <span class="ml-2">List 3</span>
                    </div>
                </div>
            </div>

            <div class="dropdown">
                <div
                    class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md justify-between dropdown-title">
                    <span class="flex">
                        <i class="bx bx-xs bx-code-alt"></i>
                        <span class="ml-2">Dropdown</span>
                    </span>
                    <i class="bx bx-xs bx-chevron-down"></i>
                </div>
                <div class="dropdown-list hidden transition-all ease-in-out duration-300">
                    <div
                        class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                        <span class="w-[25px]"></span>
                        <span class="ml-2">List 1</span>
                    </div>
                    <div
                        class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer">
                        <span class="w-[25px]"></span>
                        <span class="ml-2">List 2</span>
                    </div>
                    <div
                        class="p-2 my-1 flex hover:translate-x-1 transition-all ease-in-out duration-150 cursor-pointer text-white bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-md">
                        <span class="w-[25px]"></span>
                        <span class="ml-2">List 3</span>
                    </div>
                </div>
            </div>
        @endif

    </div>
</div>
