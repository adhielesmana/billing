@if (isset($breadcrumbs))
    <ul class="inline-flex items-center">
        @foreach ($breadcrumbs as $breadcrumb)
            @if (!$loop->last)
                <li class="inline-flex items-center">
                    <a href="{{ $breadcrumb['url'] }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600  ">
                        {{ $breadcrumb['title'] }}
                    </a>
                    <i class="bx bx-xs bx-chevron-right"></i>
                </li>
            @else
                <li aria-current="page">
                    <div class="flex items-center">
                        <span class="text-sm font-medium text-gray-500">{{ $breadcrumb['title'] }}
                </li>
            @endif
        @endforeach
    </ul>
@endif
