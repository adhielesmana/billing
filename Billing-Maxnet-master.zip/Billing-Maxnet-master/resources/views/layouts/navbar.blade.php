<div class="space-y-1" id="hamburger">
    <span class="block w-4 h-0.5 bg-gray-600"></span>
    <span class="block w-6 h-0.5 bg-gray-600"></span>
    <span class="block w-6 h-0.5 bg-gray-600"></span>
</div>

<div class="w-7 cursor-pointer relative">
    <img id="profile" class="rounded-full" src="{{ asset('storage/user_default.jpg') }}" alt="" />
    <div class="absolute w-[200px] bg-white shadow-md right-0 opacity-0 invisible -translate-y-[10px] transition-all ease-in-out duration-300 p-2"
        id="dropdown-user">

        <div class="flex items-center px-4 rounded-sm gap-2">
            <img class="rounded-full w-7 h-full" src="{{ asset('storage/user_default.jpg') }}" alt="" />
            <div class="">
                <p class="font-bold">{{ Auth::user()->full_name }}</p>
                <p>{{ App\Models\UserLevel::find(Auth::user()->user_level_id)->user_level_name }}</p>
            </div>
        </div>

        <a class="flex items-center hover:bg-gray-100 px-4 rounded-sm mt-2"
            href="{{ route('showUser', Auth::user()->user_id) }}">
            <i class="bx bx-xs bx-user"></i>
            <p class="block px-4 py-2 text-sm text-gray-700 hover:text-gray-900 ">Profile</p>
        </a>

        <a class="flex items-center hover:bg-gray-100 px-4 rounded-sm mt-2"
            href="{{ route('showUser', Auth::user()->user_id) }}"
            onclick="event.preventDefault();
                    document.getElementById('logout').submit();">
            <i class="bx bx-xs bx-power-off"></i>
            <p class="block px-4 py-2 text-sm text-gray-700 hover:text-gray-900 ">Logout</p>
        </a>

        <form id="logout" action="{{ route('logout') }}" method="POST" style="display: none;">
            @csrf
            @method('delete')
        </form>
    </div>
</div>

@push('scripts')
    <script>
        $(document).ready(function() {
            $('#profile').click(function() {
                $('#dropdown-user').toggleClass('invisible opacity-100 -translate-y-[10px] -translate-y-0');
            })
        });
    </script>
@endpush
