<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link rel="icon" type="image/x-icon" href="{{ asset('storage/logo.png') }}">
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Roboto&display=swap"
        rel="stylesheet" />
    @livewireStyles
    <style>
        [x-cloak] {
            display: none;
        }
    </style>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    @stack('styles')
    <title>Maxnet</title>
</head>

<body class="bg-slate-100 font-montserrat lg:flex">
    <div id="aside"
        class="absolute z-[11] top-0 w-[260px] h-full flex font-medium text-sm lg:static lg:w-auto -left-[100%] transition-all ease-in-out duration-150">
        @include('layouts.aside')
    </div>
    <div class="relative lg:left-[260px]">
        <div
            class="m-4 fixed z-10 top-0 bg-white shadow h-[4rem] w-[calc(100vw-2rem)] lg:w-[calc(100vw-260px-4rem)] flex items-center p-4 justify-between rounded-md">
            @include('layouts.navbar')
        </div>

        <div class="mt-[6rem] lg:w-[calc(100vw-260px-2rem)]">
            @cannot('isSales', auth()->user())
                <div class="flex m-4 p-4" aria-label="Breadcrumb">
                    @include('layouts.breadCrumb')
                </div>
            @endcannot
            @yield('content')
        </div>

    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"
        integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            // make dropdown when click open, close another dropdown, and click if dropdown is open, close it
            $(".dropdown-title").click(function() {
                if ($(this).next().hasClass("hidden")) {
                    $(".dropdown-list").addClass("hidden");
                    $(this).next().removeClass("hidden");
                } else {
                    $(".dropdown-list").addClass("hidden");
                }
            });

            // close dropdown when click outside dropdown
            $(document).click(function(event) {
                var $target = $(event.target);
                if (
                    !$target.closest(".dropdown").length &&
                    $(".dropdown-list").is(":visible")
                ) {
                    $(".dropdown-list").addClass("hidden");
                }
            });
        });

        $('#hamburger').click(function() {
            
            $('#aside').removeClass('-left-[100%]');
            $('#aside').addClass('-left-[0px]');
        })

        $('#close-sidebar').click(function() {
            $('#aside').removeClass('-left-[0px]');
            $('#aside').addClass('-left-[100%]');
        })

        $(document).on("click", function(e) {
        
            const isDropdownButton = $(e.target).is("[data-dropdown-button]");
            if (!isDropdownButton && $(e.target).closest("[data-dropdown]").length !== 0) return;

            let currentDropdown;
            if (isDropdownButton) {
                currentDropdown = $(e.target).closest("[data-dropdown]");
                currentDropdown.toggleClass("active");
            }

            $("[data-dropdown].active").each(function() {
                if ($(this)[0] === currentDropdown[0]) return;
                $(this).removeClass("active");
            });
        });
    </script>
    @stack('scripts')

</body>
@stack('livewireScripts')

</html>
