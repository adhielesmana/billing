@extends('layouts.main')

@push('styles')
    <script defer src="{{ asset('js/alphine.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('/css/flowbite.css') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
@endpush
@section('content')
    @if (session('success'))
        <div id="alert-3" class="flex mx-4 p-4 mb-4 text-green-800 border-2 border-green-300 rounded-lg bg-green-50 "
            role="alert">
            <svg aria-hidden="true" class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                    clip-rule="evenodd"></path>
            </svg>
            <span class="sr-only">Info</span>
            <div class="ml-3 text-sm font-medium">
                {{ session('success') }}
            </div>
            <button type="button"
                class="ml-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex h-8 w-8  dark:hover:bg-gray-700"
                data-dismiss-target="#alert-3" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clip-rule="evenodd"></path>
                </svg>
            </button>
        </div>
    @endif


    <div class="grid col-span-1 m-4">
        <div class="p-4 bg-white rounded-md shadow-lg w-full overflow-x-auto">
            <div
                class="text-sm font-medium text-center text-gray-500 border-b border-gray-200 dark:text-gray-400 dark:border-gray-700">
                <ul class="flex flex-wrap -mb-px">
                    @if ($page === 'table')
                        <li class="mr-2">
                            <a href="#"
                                class="inline-block p-4 text-blue-600 border-b-2 border-blue-600 rounded-t-lg active dark:text-blue-500 dark:border-blue-500"
                                aria-current="page">Table</a>
                        </li>
                    @else
                        <li class="mr-2">
                            <a href="/site?page=table"
                                class="inline-block p-4 border-b-2 border-transparent rounded-t-lg hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300">Table</a>
                        </li>
                    @endif
                    @if ($page === 'maps')
                        <li class="mr-2">
                            <a href="#"
                                class="inline-block p-4 text-blue-600 border-b-2 border-blue-600 rounded-t-lg active dark:text-blue-500 dark:border-blue-500"
                                aria-current="page">Maps</a>
                        </li>
                    @else
                        <li class="mr-2">
                            <a href="/site?page=maps"
                                class="inline-block p-4 border-b-2 border-transparent rounded-t-lg hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300">Maps</a>
                        </li>
                    @endif
                </ul>
            </div>
            <div id="map" class="h-[500px] z-0"></div>

        </div>
    </div>
@endsection



@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script>
        $(document).ready(function() {
            var map = L.map('map').setView([-7.583433518017677, 110.84037102616038], 13);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors',
                maxZoom: 18,
            }).addTo(map);

            function calculateCenter(coordinates) {
                let sumLat = 0;
                let sumLng = 0;

                for (let i = 0; i < coordinates.length; i++) {
                    sumLat += coordinates[i][0];
                    sumLng += coordinates[i][1];
                }

                const centerLat = sumLat / coordinates.length;
                const centerLng = sumLng / coordinates.length;

                return [centerLat, centerLng];
            }


            $.ajax({
                url: '/site/getsitemaps',
                method: 'GET',
                success: function(response) {
                    console.log(response);
                    var coor = [];
                    $.each(response, function(i, item) {
                        point = item.site_location_maps.split(',');
                        coor.push([parseFloat(point[0]), parseFloat(point[1])]);
                        if (item.site_type_id == 'type-olt') {
                            var marker = L.marker([point[0], point[1]], {
                                icon: createMarkerIcon('yellow')
                            }).addTo(map);
                            marker.bindPopup("<b>" + item.site_name + "</b>").openPopup();
                        } else if (item.site_type_id == 'type-odc') {
                            var marker = L.marker([point[0], point[1]], {
                                icon: createMarkerIcon('red')
                            }).addTo(map);
                            marker.bindPopup("<b>" + item.site_name + "</b>").openPopup();
                        } else if (item.site_type_id == 'type-odp') {
                            var marker = L.marker([point[0], point[1]], {
                                icon: createMarkerIcon('blue')
                            }).addTo(map);
                            marker.bindPopup("<b>" + item.site_name + "</b>").openPopup();
                        }
                    })
                    let centerMap = calculateCenter(coor)
                    map.setView(centerMap, 13);
                }
            })


            function createMarkerIcon(color) {
                return new L.Icon({
                    iconUrl: 'https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-' +
                        color +
                        '.png',
                    iconSize: [25, 41],
                    iconAnchor: [12, 41],
                    popupAnchor: [1, -34],
                });
            }
        });
    </script>
@endpush
@livewireScripts
