{{-- @if ($errors->any())
@dd($errors['foto_ktp'])
@endif --}}


@extends('layouts.main')

@push('styles')
    <link rel="stylesheet" href="{{ asset('/css/flowbite.css') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />

    <style>
        #map {
            height: 300px;
        }
    </style>
@endpush

@section('content')
    <div class="grid grid-cols-1 m-4">
        <div class="p-4 bg-white rounded-md shadow-lg w-full overflow-x-auto">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Form Entry Site</p>
            <div class="flex justify-end">
                <a href="{{ route('site') }}" class="bg-indigo-500 text-white px-4 py-2 rounded-md">Kembali</a>
            </div>
            <form action="{{ route('updateSite', $site->site_id) }}" method="post" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="mb-6">
                    <label for="site_type_id"
                        class="block mb-2 text-sm font-medium @if ($errors->has('site_type_id')) text-red-500 @else text-gray-500 @endif ">
                        Type Site</label>
                    <select id="site_type_id" name="site_type_id"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ">
                        <option value="0">Choose Type</option>
                        @foreach ($site_type as $type)
                            <option value="{{ $type->site_type_id }}" {{ $site->site_type_id == $type->site_type_id ? 'selected' : '' }}>{{ $type->site_type_name }}</option>
                        @endforeach
                    </select>
                    @error('site_type_id')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label for="site_parent"
                        class="mb-2 text-sm font-medium  @if ($errors->has('site_parent')) text-red-500 @else text-gray-500 @endif"
                        id="siteParentLabel">
                        Site Parent</label>
                    <div id="__dummy" value="{{$site->site_parent}}"></div>
                    <select id="site_parent" name="site_parent"
                        class="bg-gray-200 border border-gray-300 text-gray-500 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 "
                        disabled="disabled">
                        <option value="0">Choose Site Parent</option>
                    </select>
                    @error('site_parent')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="site_name"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_name')) text-red-500 @else text-gray-500 @endif">Name
                        Site</label>
                    <input type="site_name" id="site_name" name="site_name"
                        class="bg-gray-200 border border-gray-300 text-gray-500 cursor-no-drop @if ($errors->has('site_name')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="entry name" value="{{ old('site_name', $site->site_name) }}" readonly>
                    @error('site_name')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label for="site_description"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_description')) text-red-500 @else text-gray-500 @endif">Description</label>
                    <input type="site_description" id="site_description" name="site_description"
                        class="bg-gray-50 border @if ($errors->has('site_description')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="entry description" value="{{ old('site_description', $site->site_description) }}"
                        required>
                    @error('site_description')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="site_address"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_address')) text-red-500 @else text-gray-500 @endif">Alamat
                        Site</label>
                    <input type="site_address" id="site_address" name="site_address"
                        class="bg-gray-50 border @if ($errors->has('site_address')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="Maksukan Alamat" value="{{ old('site_address', $site->site_address) }}" required>
                    @error('site_description')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_picture')) text-red-500 @else text-gray-500 @endif"
                        for="foto-ktp">Foto Site (Optional)
                    </label>
                    <input
                        class="block w-full text-sm border @if ($errors->has('site_picture')) border-red-300 @else border-gray-300 @endif rounded-lg cursor-pointer bg-gray-50"
                        id="foto-ktp" type="file" name="site_picture">
                    @error('site_picture')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="site_location_maps" id="site_location_maps_label"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_location_maps')) text-red-500 @else text-gray-500 @endif">Koordinat
                        Map</label>
                    <div id="map" class="z-0"></div>
                    <input type="site_location_maps" id="site_location_maps" name="site_location_maps"
                        class="bg-gray-50 border mt-2 @if ($errors->has('site_location_maps')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="Sesuaikan di peta" value="{{ old('site_location_maps', $site->site_location_maps) }}"
                        required>
                    @error('site_description')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>
                <button type="submit"
                    class="text-white bg-indigo-700 hover:bg-indigo-800  focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Submit
                </button>

            </form>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script>
        $(document).ready(function() {
            function siteClear() {

                if ($('#site_parent').val() == '0' && $('#site_type_id').val() == '0') {
                    $('#site-clear').addClass('hidden');
                } else {
                    $('#site-clear').removeClass('hidden');
                }
            }
            function setSiteParent(id_parent){
                if ($('#site_type_id').val() == 'type-olt') {
                    let hiddenSiteParent = $('<input>').attr({
                        type: 'hidden',
                        id: 'site_parent',
                        name: 'site_parent',
                        value: ''
                    });
                    $('#site_parent').replaceWith(hiddenSiteParent)
                    $('#siteParentLabel').addClass('hidden');
                } else if ($('#site_type_id').val() == '0') {
                    let choosen = $('<option>').attr({
                        value: '0',
                    }).text('Choose Site Parent');
                    let disableSiteParent = $('<select>').attr({
                        id: 'site_parent',
                        name: 'site_parent',
                        class: 'bg-gray-200 border border-gray-300 text-gray-500 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ',
                        disabled: true
                    });
                    disableSiteParent.append(choosen);
                    $('#site_parent').replaceWith(disableSiteParent)
                    $('#siteParentLabel').removeClass('hidden');
                } else if ($('#site_type_id').val() == 'type-odc') {
                    let selectSiteParent = $('<select>').attr({
                        id: 'site_parent',
                        name: 'site_parent',
                        class: 'bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5'
                    });
                    $.ajax({
                        url: "{{ route('getSite', ['type' => 'type-odc']) }}",
                        type: "GET",
                        dataType: "json",
                        success: function(data) {
                            console.log(data);
                            let choosen = $('<option>').attr({
                                value: '0',
                            }).text('Choose Site Parent');
                            selectSiteParent.append(choosen);
                            $.each(data, function(key, value) {
                                let option = $('<option>').attr({
                                    value: value.site_id,
                                }).prop('selected', value.site_id == id_parent).text(value.site_name);
                                selectSiteParent.append(option);
                            });
                            $('#site_parent').replaceWith(selectSiteParent)
                            $('#siteParentLabel').removeClass('hidden');
                        }
                    });
                } else {
                    let selectSiteParent = $('<select>').attr({
                        id: 'site_parent',
                        name: 'site_parent',
                        class: 'bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 '
                    });
                    $.ajax({
                        url: "{{ route('getSite', ['type' => 'type-odp']) }}",
                        type: "GET",
                        dataType: "json",
                        success: function(data) {
                            console.log(data);
                            let choosen = $('<option>').attr({
                                value: '0',
                            }).text('Choose Site Parent');
                            selectSiteParent.append(choosen);
                            $.each(data, function(key, value) {
                                let option = $('<option>').attr({
                                    value: value.site_id,

                                }).prop('selected', value.site_id == id_parent).text(value.site_name);
                                selectSiteParent.append(option);
                            });
                            $('#site_parent').replaceWith(selectSiteParent)
                            $('#siteParentLabel').removeClass('hidden');
                        }
                    });
                }
            }
            $('#site_type_id').on('change', function() {
                console.log($(this).val());
                let select = $(this).val()
                setSiteParent()
            });

            $('#site_parent').ready(function() {
                let site_parent = $('#__dummy').attr('value');
                setSiteParent(site_parent)
            });
        });

        var map = L.map('map').fitWorld();
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap'
        }).addTo(map);
        var options = {
            position: 'topright', // Change the position of the control
            drawCircle: false, // Disable the accuracy circle
            follow: true, // Automatically follow the user's location
            keepCurrentZoomLevel: true // Maintain the current zoom level
        };


        var marker = L.marker([0, 0]);

        let coordinate = $('#site_location_maps').val();
        let lat = coordinate.split(',')[0];
        let lng = coordinate.split(',')[1];
        marker.setLatLng([lat, lng]).addTo(map);
        map.setView([lat, lng], 16);

        function onMapClick(e) {
            marker
                .setLatLng(e.latlng)
                .addTo(map);
            document.getElementById('site_location_maps').value = `${e.latlng.lat.toFixed(6)},${e.latlng.lng.toFixed(6)}`;
        }
        map.on('click', onMapClick);
    </script>
@endpush
