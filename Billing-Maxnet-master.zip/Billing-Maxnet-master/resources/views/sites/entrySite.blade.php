{{-- @if ($errors->any())
@dd($errors['foto_ktp'])
@endif --}}


@extends('layouts.main')

@push('styles')
    <link rel="stylesheet" href="{{ asset('/css/flowbite.css') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />

    <style>
        #map {
            height: 300px;
        }
    </style>
@endpush

@section('content')
    <div class="grid grid-cols-1 m-4 relative">
        <div class="bg-slate-500 absolute h-full w-full z-10 opacity-40 rounded-md" id="loader">
            <div role="status" class="h-full w-full flex justify-center mt-[200px]">
                <svg aria-hidden="true" class="w-8 h-8 mr-2 text-white animate-spin fill-black" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/>
                    <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill"/>
                </svg>
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <div class="p-4 bg-white rounded-md shadow-lg w-full overflow-x-auto ">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Form Entry Site</p>
            <div class="flex justify-end">
                <a href="{{ route('site') }}" class="bg-indigo-500 text-white px-4 py-2 rounded-md">Kembali</a>
            </div>
            <form action="{{ route('storeSite') }}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="mb-6">
                    <label for="site_type_id"
                        class="block mb-2 text-sm font-medium @if ($errors->has('site_type_id')) text-red-500 @else text-gray-500 @endif ">
                        Type Site</label>
                    <select id="site_type_id" name="site_type_id"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ">
                        <option value="0">Choose Type</option>
                        @foreach ($site_type as $type)
                            <option value="{{ $type->site_type_id }}">{{ $type->site_type_name }}</option>
                        @endforeach
                    </select>
                    @error('site_type_id')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label for="site_parent"
                        class="mb-2 text-sm font-medium @if ($errors->has('site_parent')) text-red-500 @else text-gray-500 @endif"
                        id="siteParentLabel">
                        Site Parent</label>
                    <select id="site_parent" name="site_parent"
                        class="bg-gray-200 border border-gray-300 text-gray-500 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 "
                        disabled="disabled">
                        <option value="0">Choose Site Parent</option>
                    </select>
                    @error('site_parent')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label for="site_name" id="site_name_label"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_name')) text-red-500 @else text-gray-500 @endif">Site
                        Name</label>
                    <input type="text" id="site_name" name="site_name"
                        class="bg-gray-50 border @if ($errors->has('site_name')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="example: OLT-Manahan" value="{{ old('site_name') }}" required>
                    @error('site_name')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label for="site_description"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_description')) text-red-500 @else text-gray-500 @endif">Description</label>
                    <input type="text" id="site_description" name="site_description"
                        class="bg-gray-50 border @if ($errors->has('site_description')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="entry description" value="{{ old('site_description') }}" required>
                    @error('site_description')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label for="site_port_capacity"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_port_capacity')) text-red-500 @else text-gray-500 @endif">Port Capacity</label>
                    <input type="number" id="site_port_capacity" name="site_port_capacity" min="0"
                        class="bg-gray-50 border @if ($errors->has('site_port_capacity')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="example: 16,32" value="{{ old('site_port_capacity') }}" required>
                    @error('site_port_capacity')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="site_address"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_address')) text-red-500 @else text-gray-500 @endif">Alamat
                        Site</label>
                    <input type="site_address" id="site_address" name="site_address"
                        class="bg-gray-50 border @if ($errors->has('site_address')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="Maksukan Alamat" value="{{ old('site_address') }}" required>
                    @error('site_description')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>
                <div class="mb-6">
                    <label
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_picture')) text-red-500 @else text-gray-500 @endif"
                        for="foto_site">Photo Site (Optional)
                    </label>
                    <input
                        class="block w-full text-sm border @if ($errors->has('site_picture')) border-red-300 @else border-gray-300 @endif rounded-lg cursor-pointer bg-gray-50"
                        id="foto_site" type="file" name="site_picture">
                    @error('site_picture')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="site_location_maps" id="site_location_maps_label"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('site_location_maps')) text-red-500 @else text-gray-500 @endif">Koordinat
                        Map</label>
                    <div id="map" class="z-0"></div>
                    <input type="site_location_maps" id="site_location_maps" name="site_location_maps"
                        class="bg-gray-50 border mt-2 @if ($errors->has('site_location_maps')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="Sesuaikan di peta" value="{{ old('site_location_maps') }}" required>
                    @error('site_description')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>
                <button type="submit"
                    class="text-white bg-indigo-700 hover:bg-indigo-800  focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Submit
                </button>

            </form>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script>
        $(document).ready(function() {
            $('#loader').addClass('hidden');
            $('#site_type_id').on('change', function() {
                console.log($(this).val());
                let select = $(this).val()
                if ($(this).val() == 'type-olt') {
                    let hiddenSiteParent = $('<input>').attr({
                        type: 'hidden',
                        id: 'site_parent',
                        name: 'site_parent',
                        value: ''
                    });
                    let showSiteNameLabel = $('<label>').attr({
                        for: 'site_name',
                        id: 'site_name_label',
                        class: 'block mb-2 text-sm font-medium text-gray-500'
                    }).text('Site Name');
                    let showSiteName = $('<input>').attr({
                        type: 'text',
                        id: 'site_name',
                        name: 'site_name',
                        class: 'bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ',
                        placeholder: 'example: OLT-Manahan',
                        value: ''
                    });
                    $('#site_parent').replaceWith(hiddenSiteParent)
                    $('#siteParentLabel').addClass('hidden');
                    $('#site_name').replaceWith(showSiteName)
                    $('#site_name_label').removeClass('hidden');
                } else if ($(this).val() == '0') {
                    let choosen = $('<option>').attr({
                        value: '0',
                    }).text('Choose Site Parent');
                    let disableSiteParent = $('<select>').attr({
                        id: 'site_parent',
                        name: 'site_parent',
                        class: 'bg-gray-200 border border-gray-300 text-gray-500 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ',
                        disabled: true
                    });
                    let hiddenSiteName = $('<input>').attr({
                        type: 'hidden',
                        id: 'site_name',
                        name: 'site_name',
                        value: ''
                    });
                    disableSiteParent.append(choosen);
                    $('#site_parent').replaceWith(disableSiteParent)
                    $('#siteParentLabel').removeClass('hidden');
                    $('#site_name').replaceWith(hiddenSiteName)
                    $('#site_name_label').addClass('hidden');
                } else if ($(this).val() == 'type-odc') {
                    let selectSiteParent = $('<select>').attr({
                        id: 'site_parent',
                        name: 'site_parent',
                        class: 'bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5'
                    });
                    let hiddenSiteName = $('<input>').attr({
                        type: 'hidden',
                        id: 'site_name',
                        name: 'site_name',
                        value: ''
                    });
                    $.ajax({
                        url: "{{ route('getSite', ['type' => 'type-odc']) }}",
                        type: "GET",
                        dataType: "json",
                        beforeSend: function ( xhr ) {
                            $('#loader').removeClass('hidden')
                        },
                        success: function(data) {
                            $('#loader').addClass('hidden')
                            console.log(data);
                            let choosen = $('<option>').attr({
                                value: '0',
                            }).text('Choose Site Parent');
                            selectSiteParent.append(choosen);
                            $.each(data, function(key, value) {
                                let option = $('<option>').attr({
                                    value: value.site_id,
                                }).text(value.site_name);
                                selectSiteParent.append(option);
                            });
                            $('#site_parent').replaceWith(selectSiteParent);
                            $('#siteParentLabel').removeClass('hidden');
                            $('#site_name').replaceWith(hiddenSiteName);
                            $('#site_name_label').addClass('hidden');
                        }
                    });
                } else {
                    let selectSiteParent = $('<select>').attr({
                        id: 'site_parent',
                        name: 'site_parent',
                        class: 'bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 '
                    });
                    let hiddenSiteName = $('<input>').attr({
                        type: 'hidden',
                        id: 'site_name',
                        name: 'site_name',
                        value: ''
                    });

                    $.ajax({
                        url: "{{ route('getSite', ['type' => 'type-odp']) }}",
                        type: "GET",
                        dataType: "json",
                        beforeSend: function ( xhr ) {
                            $('#loader').removeClass('hidden')
                        },
                        success: function(data) {
                            $('#loader').addClass('hidden')
                            console.log(data);
                            let choosen = $('<option>').attr({
                                value: '0',
                            }).text('Choose Site Parent');
                            selectSiteParent.append(choosen);
                            $.each(data, function(key, value) {
                                let option = $('<option>').attr({
                                    value: value.site_id,

                                }).text(value.site_name);
                                selectSiteParent.append(option);
                            });
                            $('#site_parent').replaceWith(selectSiteParent)
                            $('#siteParentLabel').removeClass('hidden');
                            $('#site_name').replaceWith(hiddenSiteName)
                            $('#site_name_label').addClass('hidden');
                        }
                    });
                }
            });
        });

        var map = L.map('map').fitWorld();
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap'
        }).addTo(map);
        map.locate({
            setView: true,
            maxZoom: 16
        });
        var options = {
            position: 'topright', // Change the position of the control
            drawCircle: false, // Disable the accuracy circle
            follow: true, // Automatically follow the user's location
            keepCurrentZoomLevel: true // Maintain the current zoom level
        };


        var marker = L.marker([0, 0]);

        function onMapClick(e) {
            marker
                .setLatLng(e.latlng)
                .addTo(map);
            document.getElementById('site_location_maps').value = `${e.latlng.lat.toFixed(6)},${e.latlng.lng.toFixed(6)}`;
        }
        map.on('click', onMapClick);
    </script>
@endpush
