@extends('layouts.main')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
    integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
@push('styles')
@endpush
@section('content')
    <div class="grid md:grid-cols-6 m-4 gap-4">
        <div class="p-4 md:col-span-4 bg-white rounded-md shadow-lg">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Data Sites</p>
            <div class="grid md:grid-cols-2 gap-4 mt-4 ">
                <div>
                    <span class="text-md text-slate-500">Name</span>
                    <p>{{ $site->site_name }}</p>
                </div>
                <div class="flex flex-col">
                    <span class="text-md text-slate-500">Parent</span>
                    <a href="{{ route('showSite', $site->site_parent) }}" class="">{{ $site->site_parent }}</a>
                </div>
                <div>
                    <span class="text-md text-slate-500">Address</span>
                    <p>{{ $site->site_address }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Created At</span>
                    <p>{{ $site->created_at }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Site Pict</span>
                    <img src="{{ asset('storage/site_picture/' . $site->site_picture) }}" alt="">
                </div>
            </div>
        </div>
        <div class="p-4 md:col-span-2 bg-white rounded-md shadow-lg">
            <div id="map" class="h-[450px] z-0" coordinates="{{ $site->site_location_maps }}" type="{{$site->site_type_id}}" name="{{$site->site_name}}"></div>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script>
        function createMarkerIcon(color) {
            return new L.Icon({
                iconUrl: 'https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-' +
                    color +
                    '.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
            });
        }

        let point = $("#map").attr("coordinates").split(",");
        let type = $("#map").attr("type");
        let name = $("#map").attr("name");
        var map = L.map('map').setView([point[0], point[1]], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors',
            maxZoom: 18,
        }).addTo(map);

        if(type == 'type-olt') {
            var marker = L.marker([point[0], point[1]], {
                icon: createMarkerIcon('yellow')
            }).addTo(map);
            marker.bindPopup("<b>" + name + "</b>").openPopup();
        } else if (type == 'type-odc') {
            var marker = L.marker([point[0], point[1]], {
                icon: createMarkerIcon('red')
            }).addTo(map);
            marker.bindPopup("<b>" + name + "</b>").openPopup();
        } else if (type == 'type-odp') {
            var marker = L.marker([point[0], point[1]], {
                icon: createMarkerIcon('blue')
            }).addTo(map);
            marker.bindPopup("<b>" + name + "</b>").openPopup();
        }
    </script>
@endpush
@livewireScripts
