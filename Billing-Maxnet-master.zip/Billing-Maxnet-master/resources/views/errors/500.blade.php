@extends('layouts.main')

@section('content')
    <div class="flex  items-center justify-center p-5">
        <div class="text-center flex flex-col">
            <div class="inline-flex rounded-full bg-red-100 p-4">
                <div class="rounded-full stroke-red-600 bg-red-200 p-4">
                    <svg class="w-16 h-16" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M6 8H6.01M6 16H6.01M6 12H18C20.2091 12 22 10.2091 22 8C22 5.79086 20.2091 4 18 4H6C3.79086 4 2 5.79086 2 8C2 10.2091 3.79086 12 6 12ZM6 12C3.79086 12 2 13.7909 2 16C2 18.2091 3.79086 20 6 20H14"
                            stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M17 16L22 21M22 16L17 21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        </path>
                    </svg>
                </div>
            </div>
            <h1 class="mt-5 text-[36px] font-bold text-slate-800 lg:text-[50px]">500 - Kesalahan Server</h1>
            <p class="text-slate-600 mt-5 lg:text-lg">Terjadi Kesalahan server hubungi administrator website ini.</p>
        </div>
        <a href="{{ url()->previous() }}"
            class="flex items-center justify-center !w-1/2 mx-auto my-4 px-5 py-2 text-sm text-gray-700 transition-colors duration-200 bg-white border border-slate-400 rounded-lg gap-x-2 sm:w-auto">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                stroke="currentColor" class="w-5 h-5 rtl:rotate-180">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 15.75L3 12m0 0l3.75-3.75M3 12h18" />
            </svg>
            <span>Kembali</span>
        </a>
    </div>
@endsection
