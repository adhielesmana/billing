<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link rel="icon" type="image/x-icon" href="{{ asset('storage/logo.png') }}">
    @livewireStyles
    <style>
        [x-cloak] {
            display: none;
        }
    </style>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <title>Maxnet</title>
</head>

<body>
    <div class="flex items-center justify-center p-5">
        <div class="text-center">
            <div class="inline-flex rounded-full bg-red-100 p-4">
                <div class="rounded-full stroke-red-600 bg-red-200 p-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="M20.5 5A1.5 1.5 0 0 0 19 6.5V11h-1V4.5a1.5 1.5 0 0 0-3 0V11h-1V3.5a1.5 1.5 0 0 0-3 0V11h-1V5.5a1.5 1.5 0 0 0-3 0v10.81l-2.22-3.6a1.5 1.5 0 0 0-2.56 1.58l3.31 5.34A5 5 0 0 0 9.78 22H17a5 5 0 0 0 5-5V6.5A1.5 1.5 0 0 0 20.5 5z"></path></svg>
                </div>
            </div>
            <h1 class="mt-5 text-[36px] font-bold text-slate-800 lg:text-[50px]">403 - Akses tidak diizinkan</h1>
            <p class="text-slate-600 mt-5 lg:text-lg">Anda tidak diizinkan masuk kehalaman ini 
            </p>
            <a href="{{ url()->previous() }}"
                class="flex items-center justify-center !w-1/2 mx-auto my-4 px-5 py-2 text-sm text-gray-700 transition-colors duration-200 bg-white border border-slate-400 rounded-lg gap-x-2 sm:w-auto">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class="w-5 h-5 rtl:rotate-180">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 15.75L3 12m0 0l3.75-3.75M3 12h18" />
                </svg>
                <span>Kembali</span>
            </a>
        </div>
</body>

</html>
