@extends('layouts.main')

@push('styles')
    <link rel="stylesheet" href="{{ asset('/css/flowbite.css') }}">
@endpush

@section('content')
    <div class="grid col-span-1 m-4">
        <div class="p-4 bg-white rounded-md shadow-lg w-full overflow-x-auto">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Form Entry Customer</p>
            <div class="flex justify-end">
                <a href="{{ route('customer') }}" class="bg-indigo-500 text-white px-4 py-2 rounded-md">Kembali</a>
            </div>
            <form action="{{ route('updateCustomer', ['id' => $data->customer_id]) }}" method="post"
                enctype="multipart/form-data">
                @csrf
                @method('PATCH')

                <div class="mb-6">
                    <label for="name"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('name')) text-red-500 @else text-gray-500 @endif">Full
                        Name</label>
                    <input type="text" id="name" name="name"
                        class="bg-gray-50 border @if ($errors->has('name')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="Full Name Customer" value="{{ old('name', $data->customer_name) }}" required>
                    @error('name')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="email"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('email')) text-red-500 @else text-gray-500 @endif">Email
                        address</label>
                    <input type="email" id="email" name="email"
                        class="bg-gray-50 border @if ($errors->has('email')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="john.doe@company.com" value="{{ old('email', $data->customer_email) }}" required>
                    @error('email')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="address"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('address')) text-red-500 @else text-gray-500 @endif">Alamat
                        Lengkap</label>
                    <input type="text" id="address" name="address"
                        class="bg-gray-50 border @if ($errors->has('address')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="Jalan Padjajaran No 24" value="{{ old('address', $data->customer_address) }}" required>
                    @error('address')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="no_phone"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('no_phone')) text-red-500 @else text-gray-500 @endif">Nomer
                        Handphone</label>
                    <input type="text" id="no_phone" name="no_phone"
                        class="bg-gray-50 border @if ($errors->has('no_phone')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="628123456789 (Mohon diawali dengan 62)"
                        value="{{ old('no_phone', $data->customer_phone) }}" required>
                    @error('no_phone')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="nik"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('nik')) text-red-500 @else text-gray-500 @endif">Nomer
                        Induk
                        Kependudukan (No KTP)</label>
                    <input type="text" id="nik" name="nik" maxlength="16" oninput="limitinputlength()"
                        class="bg-gray-50 border @if ($errors->has('nik')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="3372050000000000" value="{{ old('nik', $data->customer_ktp_no) }}" required>
                    @error('nik')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label
                        class="block mb-2 text-sm font-medium  @if ($errors->has('foto_ktp')) text-red-500 @else text-gray-500 @endif"
                        for="foto-ktp">Upload foto
                        KTP (Optional)</label>
                    <input
                        class="block w-full text-sm border @if ($errors->has('foto_ktp')) border-red-300 @else border-gray-300 @endif rounded-lg cursor-pointer bg-gray-50"
                        id="foto-ktp" type="file" name="foto_ktp">
                    @error('foto_ktp')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}
                        </p>
                    @enderror
                </div>

                <button type="submit"
                    class="text-white bg-indigo-700 hover:bg-indigo-800  focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Submit</button>
            </form>
        </div>
    </div>
@endsection

@push('scripts')
    <script defer src="{{ asset('/js/flowbite.js') }}"></script>
    <script>
        function limitInputLength() {
            var input = document.getElementById('nik');
            if (input.value.length >= 16) {
                input.value = input.value.substr(0, 16);
            }
        }
    </script>
@endpush
