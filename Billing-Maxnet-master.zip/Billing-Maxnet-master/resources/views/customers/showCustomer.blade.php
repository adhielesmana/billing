@extends('layouts.main')

@push('styles')
    <link rel="stylesheet" href="{{ asset('/css/flowbite.css') }}">
@endpush

@section('content')
    @if (session('success'))
        <div id="alert-3" class="flex mx-4 p-4 mb-4 text-green-800 border-2 border-green-300 rounded-lg bg-green-50 "
            role="alert">
            <svg aria-hidden="true" class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                    clip-rule="evenodd"></path>
            </svg>
            <span class="sr-only">Info</span>
            <div class="ml-3 text-sm font-medium">
                {{ session('success') }}
            </div>
            <button type="button"
                class="ml-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex h-8 w-8"
                data-dismiss-target="#alert-3" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clip-rule="evenodd"></path>
                </svg>
            </button>
        </div>
    @endif

    <div class="grid md:grid-cols-6 m-4 gap-4">
        <div class="p-4 md:col-span-4 bg-white rounded-md shadow-lg">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Data Customer</p>
            <div class="grid md:grid-cols-2 gap-4 mt-4 ">
                <div>
                    <span class="text-md text-slate-500">Nama</span>
                    <p>{{ $customer->customer_name }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Email</span>
                    <p>{{ $customer->customer_email }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Alamat</span>
                    <p>{{ $customer->customer_address }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">No HP</span>
                    <p>{{ $customer->customer_phone }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Nomor Induk Kependudukan</span>
                    <p>{{ $customer->customer_ktp_no }}</p>
                </div>
                <div>
                    <span class="text-md text-slate-500">Tanggal bergabung</span>
                    <p>{{ $customer->created_at }}</p>
                </div>
                <a class="text-indigo-500 cursor-pointer" href="{{ $customer->customer_ktp_picture }}" target=”_blank”>
                    <span class="text-md text-slate-500">Foto KTP</span>
                    <p>{{ $customer->customer_ktp_picture }}</p>
                </a>
            </div>
        </div>
        <div class="p-4 md:col-span-2 bg-white rounded-md shadow-lg ">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Subscribtion</p>
            <div class="overflow-y-scroll max-h-[400px]">
                @foreach ($customer->Subscription as $item)
                    <a href="{{ route('showSubscription', $customer->Subscription[$loop->index]->subscription_id) }}"
                        class="p-4 bg-slate-100 rounded-md block mb-4">
                        <p class="font-bold mb-2">{{ $customer->service[$loop->index]->service_name }}</p>
                        <div class="flex justify-between">
                            <p class="text-sm text-slate-500">Speed</p>
                            <p class="text-sm text-slate-500 font-bold">
                                {{ $customer->service[$loop->index]->service_speed }} Mbps
                            </p>
                        </div>
                        <div class="flex justify-between">
                            <p class="text-sm text-slate-500">Price</p>
                            <p class="text-sm text-slate-500 font-bold">Rp.
                                {{ number_format($customer->service[$loop->index]->service_price, 0, ',', '.') }}</p>
                        </div>
                        <div class="flex justify-between">
                            <p class="text-sm text-slate-500">Status</p>
                            <p class="text-sm text-slate-500 font-bold">
                                {{ $customer->Subscription[$loop->index]->subscription_status }}
                            </p>
                        </div>
                    </a>
                @endforeach

            </div>
        </div>
    </div>

    <div class="m-4">
        @can('update', App\Models\Customer::find($customer->customer_id))
            <a href="{{ route('editCustomer', $customer->customer_id) }}"
                class="text-white bg-blue-700 hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center mr-2 mb-2">Edit
                Customer</a>
            <button data-modal-target="authentication-modal" data-modal-toggle="authentication-modal"
                class="text-white bg-blue-700 hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center mr-2 mb-2">Ganti
                Password Customer</button>
        @endcan

        <div id="authentication-modal" tabindex="-1" aria-hidden="true"
            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
            <div class="relative w-full max-w-md max-h-full">
                <div class="relative bg-white rounded-lg shadow ">
                    <button type="button"
                        class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center"
                        data-modal-hide="authentication-modal">
                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                    <div class="px-6 py-6 lg:px-8">
                        <h3 class="mb-4 text-xl font-medium text-gray-900 ">Reset password</h3>
                        <div class="flex p-4 mb-4 text-sm text-blue-800 border border-blue-300 rounded-lg bg-blue-50 dark:bg-gray-800 dark:text-blue-400 dark:border-blue-800"
                            role="alert">
                            <svg aria-hidden="true" class="flex-shrink-0 inline w-5 h-5 mr-3" fill="currentColor"
                                viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                                    clip-rule="evenodd"></path>
                            </svg>
                            <span class="sr-only">Info</span>
                            <div>
                                <span class="font-medium">Info!</span> Pastikan customer sudah benar.
                            </div>
                        </div>
                        <form class="space-y-6" action="{{ route('resetPwdCustomer', $customer->customer_id) }}">
                            @csrf
                            <div class="flex">
                                <input type="text" id="password" name="password"
                                    class="rounded-none rounded-l-lg bg-gray-50 border border-gray-300 text-gray-900 focus:ring-blue-500 focus:border-blue-500 block flex-1 min-w-0 w-full text-sm p-2.5"
                                    placeholder="Klik tanda refresh!">
                                <span
                                    class="inline-flex items-center px-3 text-sm text-gray-900 bg-gray-200 border border-r-0 border-gray-300 rounded-r-md cursor-pointer"
                                    id="refresh-password">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                                        <path
                                            d="M10 11H7.101l.001-.009a4.956 4.956 0 0 1 .752-1.787 5.054 5.054 0 0 1 2.2-1.811c.302-.128.617-.226.938-.291a5.078 5.078 0 0 1 2.018 0 4.978 4.978 0 0 1 2.525 1.361l1.416-1.412a7.036 7.036 0 0 0-2.224-1.501 6.921 6.921 0 0 0-1.315-.408 7.079 7.079 0 0 0-2.819 0 6.94 6.94 0 0 0-1.316.409 7.04 7.04 0 0 0-3.08 2.534 6.978 6.978 0 0 0-1.054 2.505c-.028.135-.043.273-.063.41H2l4 4 4-4zm4 2h2.899l-.001.008a4.976 4.976 0 0 1-2.103 3.138 4.943 4.943 0 0 1-1.787.752 5.073 5.073 0 0 1-2.017 0 4.956 4.956 0 0 1-1.787-.752 5.072 5.072 0 0 1-.74-.61L7.05 16.95a7.032 7.032 0 0 0 2.225 1.5c.424.18.867.317 1.315.408a7.07 7.07 0 0 0 2.818 0 7.031 7.031 0 0 0 4.395-2.945 6.974 6.974 0 0 0 1.053-2.503c.027-.135.043-.273.063-.41H22l-4-4-4 4z">
                                        </path>
                                    </svg>
                                </span>
                            </div>

                            <button type="submit"
                                class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center ">Reset
                                Password</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script defer src="{{ asset('/js/flowbite.js') }}"></script>

    <script>
        $(document).ready(function() {
            $('#refresh-password').on('click', function() {
                $('#password').val(Math.random().toString(36).slice(-10));
            });
        });
    </script>
@endpush
