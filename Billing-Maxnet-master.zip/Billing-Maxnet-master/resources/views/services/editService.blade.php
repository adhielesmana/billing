@extends('layouts.main')

@push('styles')
    <link rel="stylesheet" href="{{ asset('/css/flowbite.css') }}">
@endpush

@section('content')
    <div class="grid col-span-1 m-4">
        <div class="p-4 bg-white rounded-md shadow-lg w-full overflow-x-auto">
            <p class="text-lg font-medium text-slate-500 tracking-wider">Form Entry Service</p>
            <div class="flex justify-end">
                <a href="{{ route('service') }}" class="bg-indigo-500 text-white px-4 py-2 rounded-md">Kembali</a>
            </div>

            <form action="{{ route('service.update', ['id' => $data->serv_id]) }}" method="post"
                enctype="multipart/form-data">
                @csrf
                @method('PATCH')

                <div class="mb-6">
                    <label for="name"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('name')) text-red-500 @else text-gray-500 @endif">Service
                        Name</label>
                    <input type="text" id="name" name="name"
                        class="bg-gray-50 border @if ($errors->has('name')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="Service Name" value="{{ old('name', $data->service_name) }}" required>
                    @error('name')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="desc"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('desc')) text-red-500 @else text-gray-500 @endif">Service
                        Description</label>
                    <input type="text" id="desc" name="desc"
                        class="bg-gray-50 border @if ($errors->has('desc')) border-red-300 @else border-gray-300 @endif text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                        placeholder="Service Description" value="{{ old('desc', $data->service_description) }}" required>
                    @error('desc')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-6">
                    <label for="speed"
                        class="block mb-2 text-sm font-medium  @if ($errors->has('speed')) text-red-500 @else text-gray-500 @endif">Service
                        Speed</label>
                    <div class="flex">
                        <input type="number" id="speed" name="speed" min="0"
                            class="bg-gray-50 border @if ($errors->has('speed')) border-red-300 @else border-gray-300 @endif text-sm rounded-l-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                            placeholder="Service Speed (Mbps)" value="{{ old('speed', $data->service_speed) }}" required>
                        <span
                            class="inline-flex items-center px-3 text-sm text-gray-900 bg-gray-200 border border-l-0 border-gray-300 rounded-r-md dark:bg-gray-600 dark:text-gray-400 dark:border-gray-600">
                            Mbps
                        </span>
                    </div>
                    @error('speed')
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">{{ $message }}</p>
                    @enderror
                </div>

                <div class="grid gap-6 mb-6 md:grid-cols-2">
                    <div class="mb-6">
                        <label for="price"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('price')) text-red-500 @else text-gray-500 @endif">Service
                            Price</label>
                        <div class="flex">
                            <span
                                class="inline-flex items-center px-3 text-sm text-gray-900 bg-gray-200 border border-r-0 border-gray-300 rounded-l-md dark:bg-gray-600 dark:text-gray-400 dark:border-gray-600">
                                Rp.
                            </span>
                            <input type="number" id="price" name="price"
                                class="bg-gray-50 border @if ($errors->has('price')) border-red-300 @else border-gray-300 @endif text-sm rounded-r-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                                placeholder="Price Service" value="{{ old('price', $data->service_price) }}" required>
                        </div>
                        @error('price')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <div class="mb-6">
                        <label for="discount"
                            class="block mb-2 text-sm font-medium  @if ($errors->has('discount')) text-red-500 @else text-gray-500 @endif">Service
                            Discount</label>
                        <div class="flex">
                            <input type="number" id="discount" name="discount" min="0"
                                class="bg-gray-50 border @if ($errors->has('discount')) border-red-300 @else border-gray-300 @endif text-sm rounded-l-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                                placeholder="Service Dicount" value="{{ old('discount', $data->service_discount) }}"
                                required>
                            <span
                                class="inline-flex items-center px-3 text-sm text-gray-900 bg-gray-200 border border-l-0 border-gray-300 rounded-r-md dark:bg-gray-600 dark:text-gray-400 dark:border-gray-600">
                                %
                            </span>
                        </div>
                        @error('discount')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span
                                    class="font-medium">{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>

                <button type="submit"
                    class="text-white bg-indigo-700 hover:bg-indigo-800  focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Submit</button>
            </form>
        </div>
    </div>
@endsection

@push('scripts')
    <script defer src="{{ asset('/js/flowbite.js') }}"></script>
@endpush
