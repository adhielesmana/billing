<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\SubscriptionController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\SiteController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Dashboard
Route::get('/', function () {
    return view('home');
})->name('home')->middleware('auth');


// Customer
Route::group(['middleware' => ['auth']], function () {
    Route::prefix('customer')->group(function () {
        Route::get('/', [CustomerController::class, 'index'])->name('customer');
        Route::get('/entry', [CustomerController::class, 'show'])->name('entryCustomer');
        Route::get('/{id}', [CustomerController::class, 'showCustomer'])->name('showCustomer');
        Route::post('/entry', [CustomerController::class, 'create'])->name('createCustomer');
        Route::get('/{id}/edit', [CustomerController::class, 'edit'])->name('editCustomer');
        Route::get('/{id}/resetpwd', [CustomerController::class, 'resetpwd'])->name('resetPwdCustomer');
        Route::patch('/{id}/update', [CustomerController::class, 'update'])->name('updateCustomer');
        Route::delete('/{id}', [CustomerController::class, 'destroy'])->name('deleteCustomer');
    });
});

// Subscription
Route::group(['middleware' => ['auth']], function () {
    Route::prefix('subscription')->group(function () {
        Route::get('/', [SubscriptionController::class, 'index'])->name('subscription');
        Route::get('/entry', [SubscriptionController::class, 'initialCreate'])->name('entryInitSubscription');
        Route::get('/{id}', [SubscriptionController::class, 'show'])->name('showSubscription');
        Route::get('/{id}/edit', [SubscriptionController::class, 'edit'])->name('editSubscription');
        Route::post('/entry', [SubscriptionController::class, 'initialStore'])->name('storeInitSubscription');
        Route::patch('/{id}/edit', [SubscriptionController::class, 'update'])->name('updateSubscription');
        Route::patch('/{id}/activate', [SubscriptionController::class, 'activate'])->name('activateSubscription');
        Route::patch('/{id}/proceed', [SubscriptionController::class, 'proceed'])->name('proceedSubscription');
        Route::patch('/{id}/decline', [SubscriptionController::class, 'decline'])->name('declineSubscription');
        Route::get('/{id}/technician-entry', [SubscriptionController::class, 'technicianCreate'])->name('entryTechSubscription');
        Route::patch('/{id}/technician-entry', [SubscriptionController::class, 'technicianUpdate'])->name('updateTechSubscription');
    });
});

// User
Route::group(['middleware' => ['auth']], function () {
    Route::prefix('/user')->group(function () {
        Route::get('/', [AuthController::class, 'index'])->name('user');
        Route::get('/invite', [AuthController::class, 'invite'])->name('invite');
        Route::post('/invite', [AuthController::class, 'invited'])->name('invited');
        Route::get('/{id}/edit', [AuthController::class, 'edit'])->name('editUser');
        Route::put('/{id}/update', [AuthController::class, 'update'])->name('updateUser');
        Route::patch('/{id}/resetpwd', [AuthController::class, 'resetpwd'])->name('resetPwdUser');
        Route::get('/{id}', [AuthController::class, 'showUser'])->name('showUser');
        Route::delete('/{id}', [AuthController::class, 'destroy'])->name('deleteUser');
    });
});

// Login
Route::get('/login', [AuthController::class, 'login'])->name('login')->middleware('guest');
Route::post('/login', [AuthController::class, 'logged'])->name('logged')->middleware('guest');
Route::get('/register', [AuthController::class, 'register'])->name('register')->middleware('guest');
Route::patch('/register', [AuthController::class, 'registered'])->name('registered')->middleware('guest');
Route::delete('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// Service
Route::group(['middleware' => ['auth']], function () {
    Route::prefix('/service')->group(function () {
        Route::get('/', [ServiceController::class, 'index'])->name('service');
        Route::get('/entry', [ServiceController::class, 'create'])->name('service.create');
        Route::post('/entry', [ServiceController::class, 'store'])->name('service.store');
        Route::get('/{id}/edit', [ServiceController::class, 'edit'])->name('service.edit');
        Route::patch('/{id}/update', [ServiceController::class, 'update'])->name('service.update');
        Route::delete('/{id}', [ServiceController::class, 'destroy'])->name('service.destroy');
    });
});

Route::group(['middleware' => ['auth']], function () {
    Route::prefix('site')->group(function () {
        Route::get('/', [SiteController::class, 'sites'])->name('site');
        Route::get('/entry', [SiteController::class, 'create'])->name('entrySite');
        route::get('/getsite', [SiteController::class, 'getSite'])->name('getSite');
        route::get('/getsitemaps', [SiteController::class, 'getSiteMaps'])->name('getsitemaps');
        Route::get('/{id}', [SiteController::class, 'show'])->name('showSite');
        Route::post('/entry', [SiteController::class, 'store'])->name('storeSite');
        Route::get('/{id}/edit', [SiteController::class, 'edit'])->name('editSite');
        Route::put('/{id}/update', [SiteController::class, 'update'])->name('updateSite');
        Route::delete('/{id}', [SiteController::class, 'destroy'])->name('deleteSite');
    });
});

// Error
Route::get('/error', [Controller::class, 'index'])->name('error');
