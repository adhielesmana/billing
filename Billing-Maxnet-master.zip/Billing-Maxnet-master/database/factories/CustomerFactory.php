<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class CustomerFactory extends Factory
{
    public function definition()
    {
        return [
            'customer_id' => Str::random(10),
            'customer_password' => Str::random(10),
            'customer_name' => fake()->name(),
            'customer_email' => fake()->unique()->safeEmail(),
            'customer_address' => fake()->address(),
            'customer_phone' => fake()->phoneNumber(),
            'customer_ktp_no' => fake()->randomNumber(9),
            'customer_ktp_picture' => fake()->imageUrl(),
            'password_reset' => fake()->boolean(),
        ];
    }
}
