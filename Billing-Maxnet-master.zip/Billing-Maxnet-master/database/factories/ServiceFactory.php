<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;
use Illuminate\Support\Arr;

class ServiceFactory extends Factory
{
    public function definition()
    {
        return [
            'serv_id' => Str::random(10),
            'service_name' => fake()->word(),
            'service_speed' => Arr::random([10, 20, 30, 40, 50, 100]),
            'service_description' => fake()->sentence(5),
            'service_price' => fake()->numberBetween(200000, 1000000),
            'service_discount' => fake()->numberBetween(0, 100)
        ];
    }
}
