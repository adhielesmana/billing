<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class SiteTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $siteType = new \App\Models\SiteType;
        $siteType->site_type_id = "type-olt";
        $siteType->site_type_name = "OLT";
        $siteType->site_type_description = "Optical Line Terminal";
        $siteType->save();

        $siteType = new \App\Models\SiteType;
        $siteType->site_type_id = "type-odc";
        $siteType->site_type_name = "ODC";
        $siteType->site_type_description = "Optical Distribution Cabinet";
        $siteType->save();

        $siteType = new \App\Models\SiteType;
        $siteType->site_type_id = "type-odp";
        $siteType->site_type_name = "ODP";
        $siteType->site_type_description = "Optical Distribution Point";
        $siteType->save();
    }
}
