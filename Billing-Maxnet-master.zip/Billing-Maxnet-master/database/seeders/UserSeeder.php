<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = new \App\Models\User;
        // make me seeder for user
        $user->user_id = Str::random(10);
        $user->full_name = "admin";
        $user->username = "admin";
        $user->email = "admin@admin.com";
        $user->password = bcrypt("admin");
        $user->user_level_id = "23001";
        $user->save();

        $user = new \App\Models\User;
        // make me seeder for user
        $user->user_id = Str::random(10);
        $user->full_name = "noc";
        $user->username = "noc";
        $user->email = "noc@noc.com";
        $user->password = bcrypt("noc");
        $user->user_level_id = "23002";
        $user->save();

        $user = new \App\Models\User;
        // make me seeder for user
        $user->user_id = Str::random(10);
        $user->full_name = "sales";
        $user->username = "sales";
        $user->email = "sales@sales.com";
        $user->password = bcrypt("sales");
        $user->user_level_id = "23003";
        $user->save();


        $user = new \App\Models\User;
        // make me seeder for user
        $user->user_id = Str::random(10);
        $user->full_name = "teknisi";
        $user->username = "teknisi";
        $user->email = "teknisi@teknisi.com";
        $user->password = bcrypt("teknisi");
        $user->user_level_id = "23004";
        $user->save();

        $user = new \App\Models\User;
        // make me seeder for user
        $user->user_id = Str::random(10);
        $user->full_name = "biller";
        $user->username = "biller";
        $user->email = "biller@biller.com";
        $user->password = bcrypt("biller");
        $user->user_level_id = "23005";
        $user->save();
    }
}
