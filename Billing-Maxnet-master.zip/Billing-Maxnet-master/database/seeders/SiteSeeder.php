<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class SiteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $site = new \App\Models\Site;
        $site->site_name = "OLT-Pajang";
        $site->site_parent = "";
        $site->site_type_id = "type-olt";
        $site->site_description = "Optical Line Terminal";
        $site->site_picture = "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.alibaba.com%2Fproduct-detail%2F1-64-SC-APC-PLC-Optical_60796982157.html&psig=AOvVaw0QZ2Z3Z2Z3Z2Z3Z2Z3Z2Z3&ust=1623758970002000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJjQ4ZqH0_ECFQAAAAAdAAAAABAD";
        $site->site_location_maps = "-7.555827, 110.805375";
        $site->site_address = "Jl. Raya Bogor KM 30";
        $site->save();

        $site = new \App\Models\Site;
        $site->site_name = "OLT-Pasar Kliwon";
        $site->site_parent = "";
        $site->site_type_id = "type-olt";
        $site->site_description = "Optical Line Terminal";
        $site->site_picture = "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.alibaba.com%2Fproduct-detail%2F1-64-SC-APC-PLC-Optical_60796982157.html&psig=AOvVaw0QZ2Z3Z2Z3Z2Z3Z2Z3Z2Z3&ust=1623758970002000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJjQ4ZqH0_ECFQAAAAAdAAAAABAD";
        $site->site_location_maps = "-7.555827, 110.805375";
        $site->site_address = "Jl. Raya Bogor KM 30";
        $site->save();

        $site = new \App\Models\Site;
        $site->site_name = "ODC-1";
        $site->site_parent = "site-1";
        $site->site_type_id = "type-odc";
        $site->site_description = "Optical Distribution Cabinet";
        $site->site_picture = "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.alibaba.com%2Fproduct-detail%2F1-64-SC-APC-PLC-Optical_60796982157.html&psig=AOvVaw0QZ2Z3Z2Z3Z2Z3Z2Z3Z2Z3&ust=1623758970002000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJjQ4ZqH0_ECFQAAAAAdAAAAABAD";
        $site->site_location_maps = "-7.555827, 110.805375";
        $site->site_address = "Jl. Raya Bogor KM 30";
        $site->save();

        $site = new \App\Models\Site;
        $site->site_name = "ODP-1";
        $site->site_parent = "site-3";
        $site->site_type_id = "type-odp";
        $site->site_description = "Optical Distribution Point";
        $site->site_picture = "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.alibaba.com%2Fproduct-detail%2F1-64-SC-APC-PLC-Optical_60796982157.html&psig=AOvVaw0QZ2Z3Z2Z3Z2Z3Z2Z3Z2Z3&ust=1623758970002000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJjQ4ZqH0_ECFQAAAAAdAAAAABAD";
        $site->site_location_maps = "-7.555827, 110.805375";
        $site->site_address = "Jl. Raya Bogor KM 30";
        $site->save();

        $site = new \App\Models\Site;
        $site->site_name = "ODP-2";
        $site->site_parent = "site-3";
        $site->site_type_id = "type-odp";
        $site->site_description = "Optical Distribution Point";
        $site->site_picture = "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.alibaba.com%2Fproduct-detail%2F1-64-SC-APC-PLC-Optical_60796982157.html&psig=AOvVaw0QZ2Z3Z2Z3Z2Z3Z2Z3Z2Z3&ust=1623758970002000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJjQ4ZqH0_ECFQAAAAAdAAAAABAD";
        $site->site_location_maps = "-7.555827, 110.805375";
        $site->site_address = "Jl. Raya Bogor KM 30";
        $site->save();

        $site = new \App\Models\Site;
        $site->site_name = "ODP-3";
        $site->site_parent = "site-3";
        $site->site_type_id = "type-odp";
        $site->site_description = "Optical Distribution Point";
        $site->site_picture = "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.alibaba.com%2Fproduct-detail%2F1-64-SC-APC-PLC-Optical_60796982157.html&psig=AOvVaw0QZ2Z3Z2Z3Z2Z3Z2Z3Z2Z3&ust=1623758970002000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJjQ4ZqH0_ECFQAAAAAdAAAAABAD";
        $site->site_location_maps = "-7.555827, 110.805375";
        $site->site_address = "Jl. Raya Bogor KM 30";
        $site->save();
    }
}
