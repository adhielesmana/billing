<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class UserLevelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user_level = new \App\Models\UserLevel;
        $user_level->user_level_id = "23001";
        $user_level->user_level_name = "admin";
        $user_level->user_level_description = "Administrator";
        $user_level->save();

        $user_level = new \App\Models\UserLevel;
        $user_level->user_level_id = "23002";
        $user_level->user_level_name = "noc";
        $user_level->user_level_description = "Network Operation Center";
        $user_level->save();

        $user_level = new \App\Models\UserLevel;
        $user_level->user_level_id = "23003";
        $user_level->user_level_name = "sales";
        $user_level->user_level_description = "Sales";
        $user_level->save();

        $user_level = new \App\Models\UserLevel;
        $user_level->user_level_id = "23004";
        $user_level->user_level_name = "teknisi";
        $user_level->user_level_description = "Teknisi";
        $user_level->save();


        $user_level = new \App\Models\UserLevel;
        $user_level->user_level_id = "23005";
        $user_level->user_level_name = "biller";
        $user_level->user_level_description = "Biller";
        $user_level->save();
    }
}
