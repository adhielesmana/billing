<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('subscriptions', function (Blueprint $table) {
            $table->string('subscription_id')->primary();
            $table->string('subscription_password');
            $table->string('customer_id')->references('customer_id')->on('customers');
            $table->string('serv_id')->references('serv_id')->on('services');
            $table->string('group');
            $table->string('created_by')->references('user_id')->on('users');
            $table->string('subscription_start_date')->nullable();
            $table->string('subscription_billing_cycle')->nullable();
            $table->string('subscription_price')->nullable();
            $table->string('subscription_address')->nullable();
            $table->string('subscription_status')->nullable();
            $table->string('subscription_maps')->nullable();
            $table->string('subscription_home_photo')->nullable();
            $table->string('subscription_form_scan')->nullable();
            $table->string('subscription_description')->nullable();
            $table->string('cpe_type')->nullable();
            $table->string('cpe_serial')->nullable();
            $table->string('cpe_picture')->nullable();
            $table->string('cpe_site')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subscriptions');
    }
};
