<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class BreadcrumbMiddleware
{
    public function handle($request, Closure $next)
    {
        $segments = $request->segments();

        $breadcrumbs = collect();

        foreach ($segments as $segment) {
            $breadcrumb = [
                'url' => url(implode('/', array_slice($segments, 0, array_search($segment, $segments) + 1))),
                'title' => ucfirst(str_replace('-', ' ', $segment))
            ];

            $breadcrumbs->push($breadcrumb);
        }

        view()->share('breadcrumbs', $breadcrumbs);

        return $next($request);
    }
}