<?php

namespace App\Http\Controllers;

use App\Models\Subscription;
use App\Models\Customer;
use App\Models\Service;
use App\Models\Site;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class SubscriptionController extends Controller
{
    public function index()
    {
        Gate::authorize('viewAny', Subscription::class);
        return view('subscriptions.subscription');
    }

    public function initialCreate()
    {
        Gate::authorize('createSales', Subscription::class);
        $customer = '';

        if (request('search')) {
            $customer = Customer::firstWhere('customer_ktp_no', request('search'));
        }

        $sites = Site::all()->where('site_type_id', 'type-odp');

        return view('subscriptions.entryInitialSub', [
            "customerData" => $customer,
            "serviceData" => Service::all(),
            "sites" => $sites,
        ]);
    }

    public function technicianCreate(Request $request, $id)
    {
        $data = Subscription::find($id);
        Gate::authorize('createTeknisi', Subscription::class);
        // $sites = Site::all()->where('site_type_id', 'type-odp');

        return view('subscriptions.entryTechnicianSub', compact('data'));
    }

    public function initialStore(Request $request)
    {
        Gate::authorize('createSales', Subscription::class);
        $validated = $request->validate([
            "service" => "required | not_in:0",
            "custom_price" => "nullable | numeric",
            "group" => "required | numeric",
            "subscription_map" => "required",
            "address" => "required | min:10",
            "subscription_home" => "required | mimes:jpg,png,jpeg",
            "cpe_site" => "required | not_in:0",
        ]);

        $subscription = new Subscription;
        $subscription->customer_id = $request->customerId;
        $subscription->subscription_password = preg_replace('/[^0-9]/', '', $request->telp);
        $subscription->serv_id = $validated['service'];
        $subscription->subscription_price = $validated['custom_price'];
        $subscription->group = $validated['group'];
        $subscription->subscription_maps = $validated['subscription_map'];
        $subscription->subscription_address = $validated['address'];
        $subscription->cpe_site = $validated['cpe_site'];
        $subscription->subscription_status = 'NEW REQUEST';
        $subscription->created_by = auth()->user()->user_id;

        // Home Photos
        if ($request->file('subscription_home') != null) {
            $subscription->subscription_home_photo = $subscription->generateSubscriptionId() . '-home_photo' . '.' . $request->file('subscription_home')->getClientOriginalExtension();
            Storage::delete('public/sub_home/' . $subscription->subscription_home_photo);
            $request->file('subscription_home')->storeAs('public/sub_home', $subscription->subscription_home_photo);
        } else {
            $subscription->subscription_home_photo = '-';
        }

        Subscription::create($subscription->toArray());

        return redirect()->route('subscription')->with('success', 'Initial Subscription created successfully');
    }

    public function technicianUpdate(Request $request, $id)
    {
        $subscription = Subscription::findOrFail($id);
        Gate::authorize('updateTeknisi', $subscription);
        $validated = $request->validate([
            "subscription_form" => "required | mimes:jpg,png,jpeg",
            "cpe_serial" => "required | min:10",
            "cpe_picture" => "required | mimes:jpg,png,jpeg",
            "cpe_type" => "required",
        ]);

        $subscription->cpe_serial = $validated['cpe_serial'];
        $subscription->cpe_type = $validated['cpe_type'];
        $subscription->subscription_status = 'INSTALLED';

        // Form Scan
        if ($request->file('subscription_form') != null) {
            $subscription->subscription_form_scan = $id . '-form_scan' . '.' . $request->file('subscription_form')->getClientOriginalExtension();
            Storage::delete('public/sub_form/' . $subscription->subscription_form_scan);
            $request->file('subscription_form')->storeAs('public/sub_form', $subscription->subscription_form_scan);
        } else {
            $subscription->subscription_form_scan = '-';
        }

        // CPE Picture
        if ($request->file('cpe_picture') != null) {
            $subscription->cpe_picture = $id . '-home_photo' . '.' . $request->file('cpe_picture')->getClientOriginalExtension();
            Storage::delete('public/sub_cpe/' . $subscription->cpe_picture);
            $request->file('cpe_picture')->storeAs('public/sub_cpe', $subscription->cpe_picture);
        } else {
            $subscription->cpe_picture = '-';
        }

        $subscription->save();

        return redirect()->route('subscription')->with('success', 'Subscription tech updated successfully');
    }

    public function update(Request $request, $id)
    {
        $subscription = Subscription::findOrFail($id);
        Gate::authorize('update', $subscription);
        $validated = $request->validate([
            "service" => "required",
            "price" => "nullable | numeric",
            "group" => "required | numeric",
            "address" => "required | min:10",
            "subscription_map" => "",
            "subscription_home" => "mimes:jpg,png,jpeg",
            "subscription_form" => "mimes:jpg,png,jpeg",
            "cpe_serial" => "",
            "cpe_picture" => "mimes:jpg,png,jpeg",
            "cpe_site" => "",
            "cpe_type" => "",
        ]);

        $subscription->serv_id = $validated['service'];
        $subscription->subscription_price = $validated['price'];
        $subscription->group = $validated['group'];
        $subscription->subscription_address = $validated['address'];
        $subscription->subscription_maps = $validated['subscription_map'];
        $subscription->cpe_serial = $validated['cpe_serial'];
        $subscription->cpe_site = $validated['cpe_site'];
        $subscription->cpe_type = $validated['cpe_type'];

        // Home Photos
        if ($request->file('subscription_home') != null) {
            $subscription->subscription_home_photo = $id . '-home_photo' . '.' . $request->file('subscription_home')->getClientOriginalExtension();
            Storage::delete('public/sub_home/' . $subscription->subscription_home_photo);
            $request->file('subscription_home')->storeAs('public/sub_home', $subscription->subscription_home_photo);
        } else {
            $subscription->subscription_home_photo = $subscription->subscription_home_photo;
        }

        // Form Scan
        if ($request->file('subscription_form') != null) {
            $subscription->subscription_form_scan = $id . '-form_scan' . '.' . $request->file('subscription_form')->getClientOriginalExtension();
            Storage::delete('public/sub_form/' . $subscription->subscription_form_scan);
            $request->file('subscription_form')->storeAs('public/sub_form', $subscription->subscription_form_scan);
        } else {
            $subscription->subscription_form_scan = $subscription->subscription_form_scan;
        }

        // CPE Picture
        if ($request->file('cpe_picture') != null) {
            $subscription->cpe_picture = $id . '-home_photo' . '.' . $request->file('cpe_picture')->getClientOriginalExtension();
            Storage::delete('public/sub_cpe/' . $subscription->cpe_picture);
            $request->file('cpe_picture')->storeAs('public/sub_cpe', $subscription->cpe_picture);
        } else {
            $subscription->cpe_picture = $subscription->cpe_picture;
        }

        $subscription->save();

        return redirect()->route('subscription')->with('success', 'Subscription updated successfully');
    }

    public function show(Request $request, $id)
    {
        $data = Subscription::find($id);
        Gate::authorize('view', $data);
        return view('subscriptions.showSubscription', compact('data'));
    }

    public function edit($id)
    {
        // Gate::authorize('view', $data);
        $data = Subscription::find($id);
        return view('subscriptions.editSubscription', [
            "data" => $data,
            "serviceData" => Service::all()
        ]);
    }

    public function activate(Request $request, $id)
    {
        $sub = Subscription::find($id);
        $date = Carbon::now();
        Gate::authorize('update', $sub);
        $sub->subscription_start_date = $date->toDateString();
        $sub->subscription_billing_cycle = $date->subDays(7)->format('d');
        $sub->subscription_status = 'ACTIVE';
        $sub->save();

        return redirect()->route('showSubscription', $id)->with('success', 'Data Subscription Activated');
    }

    public function proceed(Request $request, $id)
    {
        $sub = Subscription::find($id);
        Gate::authorize('update', $sub);
        $sub->subscription_status = 'PROCEED';
        $sub->save();

        return redirect()->route('showSubscription', $id)->with('success', 'Data Subscription Proceed');
    }

    public function decline($id)
    {
        $sub = Subscription::find($id);
        Gate::authorize('update', $sub);
        $sub->subscription_status = 'CANCELED';
        $sub->save();

        return redirect()->route('showSubscription', $id)->with('success', 'Data Subscription Canceled');
    }
}
