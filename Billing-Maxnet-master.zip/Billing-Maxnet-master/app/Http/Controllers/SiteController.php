<?php

namespace App\Http\Controllers;

use App\Models\Site;
use App\Http\Requests\UpdateSiteRequest;
use App\Models\SiteType;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;

class SiteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function sites(Request $request)
    {
        Gate::authorize('viewAny', Site::class);
        if ($request->query('page') == 'maps') {
            return view('sites.siteMaps')->with('page', 'maps');
        } elseif ($request->query('page') == 'table') {
            return view('sites.siteTable')->with('page', 'table');
        } else {
            return view('sites.siteTable')->with('page', 'table');
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Site $site)
    {
        
        Gate::authorize('create', Site::class);
        $sites = Site::all();
        $site_type = SiteType::all();
        return view('sites.entrySite', compact('sites', 'site_type'));
    }

    public function getSite(Request $request)
    {
        if ($request->ajax()) {
            // get query string from ajax request
            $query = $request->get('type');
            if ($query == 'type-odc') {
                $sites = Site::all()->where('site_type_id', 'type-olt');
            } elseif ($query == 'type-odp') {
                $sites = Site::all()->where('site_type_id', 'type-odc');
            }
            return $sites;
        } else {
            abort(403, 'Forbidden');
        }
    }

    public function getSiteMaps(Request $request){
        if ($request->ajax()) {
            $sites = Site::all();
            return $sites;
        }else{
            abort(403, 'Forbidden');
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreSiteRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Site $site)
    {
        Gate::authorize('create', Site::class);
        $validated = null;

        if ($request->site_type_id == 'type-olt') {
            $validated = $request->validate([
                'site_address' => 'required || min:10',
                'site_description' => 'required || min:10',
                'site_port_capacity' => 'required',
                'site_name'=> 'required',
                'site_type_id' => 'required || not_in:0',
                'site_port_capacity' => 'required',
                'site_picture' => 'mimes:jpg,png,jpeg',
                'site_location_maps' => 'required'
            ]);
            $validated['site_parent'] = '';
        } else if ($request->site_type_id == 'type-odc') {
            $validated = $request->validate([
                'site_parent' => 'required || not_in:0',
                'site_address' => 'required || min:10',
                'site_description' => 'required || min:10',
                'site_port_capacity' => 'required',
                'site_type_id' => 'required || not_in:0',
                'site_picture' => 'mimes:jpg,png,jpeg',
                'site_location_maps' => 'required'
            ]);
            $siteCount = Site::where('site_parent', $request['site_parent'])->count();
            $validated['site_name'] = "ODC" . '-' . $siteCount + 1;
        }else if ($request->site_type_id == 'type-odp'){
            $validated = $request->validate([
                'site_parent' => 'required || not_in:0',
                'site_address' => 'required || min:10',
                'site_description' => 'required || min:10',
                'site_port_capacity' => 'required',
                'site_type_id' => 'required || not_in:0',
                'site_picture' => 'mimes:jpg,png,jpeg',
                'site_location_maps' => 'required'
            ]);
            $siteCount = Site::where('site_parent', $request['site_parent'])->count();
            $validated['site_name'] = "ODP" . '-' . $siteCount + 1;
        }

        $site = new Site();

        $site->site_name = $validated['site_name'];
        $site->site_port_capacity = $validated['site_port_capacity'];
        $site->site_address = $validated['site_address'];
        $site->site_description = $validated['site_description'];
        $site->site_type_id = $validated['site_type_id'];
        $site->site_parent = $validated['site_parent'];
        $site->site_location_maps = $validated['site_location_maps'];

        //change name customer_ktp_picture to nik with extension
        $site->site_picture = $site->generateSiteId() . '.' . $request->file('site_picture')->getClientOriginalExtension();
        // save to storage
        $request->file('site_picture')->storeAs('public/site_picture', $site->site_picture);

        $site->save();

        return redirect()->route('site')->with('success', 'Site created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Site  $site
     * @return \Illuminate\Http\Response
     */
    public function show(Site $site, $id)
    {
        $site = Site::find($id);
        Gate::authorize('view', $site);
        return view('sites.showSite', compact('site'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Site  $site
     * @return \Illuminate\Http\Response
     */
    public function edit(Site $site, $id)
    {
        $site = Site::find($id);
        Gate::authorize('update', $site);
        $site_type = SiteType::all();
        return view('sites.editSite', compact('site', 'site_type'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateSiteRequest  $request
     * @param  \App\Models\Site  $site
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Site $site, $id)
    {
        Gate::authorize('update', $site);
        $site = Site::findOrFail($id);
        // dd($request->site_type_id == $site->site_type_id);
        if ($request->site_type_id == 'type-olt' && $request->site_type_id != $site->site_type_id) {
            $validated = $request->validate([
                'site_address' => 'required || min:10',
                'site_description' => 'required || min:10',
                'site_port_capacity' => 'required',
                'site_type_id' => 'required || not_in:0',
                'site_picture' =>  'mimes:jpg,png,jpeg',
                'site_location_maps' => 'required'
            ]);
            $validated['site_parent'] = '';
            $validated['site_name'] = "OLT" . '-' . Site::where('site_type_id', $validated['site_type_id'])->count() + 1;
        } else if ($request->site_type_id == 'type-odc' && $request->site_type_id != $site->site_type_id) {
            $validated = $request->validate([
                'site_parent' => 'required || not_in:0',
                'site_address' => 'required || min:10',
                'site_description' => 'required || min:10',
                'site_port_capacity' => 'required',
                'site_type_id' => 'required || not_in:0',
                'site_picture' =>  'mimes:jpg,png,jpeg',
                'site_location_maps' => 'required'
            ]);
            $siteCount = Site::where('site_parent', $request['site_parent'])->count();
            $validated['site_name'] = "ODC" . '-' . $siteCount + 1 . ' => ' . $site -> find($validated['site_parent'])->site_name;
        } else if($request->site_type_id == 'type-odp' && $request->site_type_id != $site->site_type_id){ 
            $validated = $request->validate([
                'site_parent' => 'required || not_in:0',
                'site_address' => 'required || min:10',
                'site_description' => 'required || min:10',
                'site_port_capacity' => 'required',
                'site_type_id' => 'required || not_in:0',
                'site_picture' =>  'mimes:jpg,png,jpeg',
                'site_location_maps' => 'required'
            ]);
            $siteCount = Site::where('site_parent', $request['site_parent'])->count();
            $validated['site_name'] = "ODP" . '-' . $siteCount + 1 . ' => ' . explode(" => ", $site -> find
            ($validated['site_parent'])->site_name)[0];
        } else{
            $validated = $request->validate([
                'site_parent' => 'not_in:0',
                'site_address' => 'required || min:10',
                'site_description' => 'required || min:10',
                'site_port_capacity' => 'required',
                'site_type_id' => 'required || not_in:0',
                'site_picture' =>  'mimes:jpg,png,jpeg',
                'site_location_maps' => 'required'
            ]);
            $validated['site_name'] = $site->site_name;
            $validated['site_parent'] = $site->site_parent;
            // dd($validated['site_name']);
        }

        $site->site_id = $site->site_id;
        $site->site_name = $validated['site_name'];
        $site->site_address = $validated['site_address'];
        $site->site_description = $validated['site_description'];
        $site->site_type_id = $validated['site_type_id'];
        $site->site_parent = $validated['site_parent'];
        $site->site_location_maps = $validated['site_location_maps'];

        if ($request->file('site_picture') != null) {
            Storage::delete('public/site_picture' .$site->site_picture);
            $site->site_picture = $site->site_picture = $request->site_id . '.' . $request->file('site_picture')->getClientOriginalExtension();
            $request->file('site_picture')->storeAs('public/site_picture',$site->site_picture);
        } else {
           $site->site_picture = $site->site_picture;
        }
        $site->save();

        return redirect()->route('site')->with('success', 'Site updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Site  $site
     * @return \Illuminate\Http\Response
     */
    public function destroy(Site $site)
    {
        //
    }
}
