<?php

namespace App\Http\Controllers;

use App\Models\SiteType;
use App\Http\Requests\StoreSiteTypeRequest;
use App\Http\Requests\UpdateSiteTypeRequest;

class SiteTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreSiteTypeRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSiteTypeRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SiteType  $siteType
     * @return \Illuminate\Http\Response
     */
    public function show(SiteType $siteType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SiteType  $siteType
     * @return \Illuminate\Http\Response
     */
    public function edit(SiteType $siteType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateSiteTypeRequest  $request
     * @param  \App\Models\SiteType  $siteType
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateSiteTypeRequest $request, SiteType $siteType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SiteType  $siteType
     * @return \Illuminate\Http\Response
     */
    public function destroy(SiteType $siteType)
    {
        //
    }
}
