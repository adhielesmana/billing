<?php

namespace App\Http\Controllers;

use App\Models\Customer;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Gate;

class CustomerController extends Controller
{

    public function index()
    {
        Gate::authorize('viewAny', Customer::class);
        return view('customers.customer');
    }

    public function show(Customer $customer)
    {
        Gate::authorize('create', $customer);
        return view('customers.entryCustomer');
    }

    public function showCustomer(Request $request, $id)
    {
        $customer = Customer::findOrFail($id);
        Gate::authorize('view', $customer);
        return view('customers.showCustomer', compact('customer'));
    }

    public function edit(Customer $customer, $id)
    {
        Gate::authorize('update', $customer);
        $data = Customer::findOrFail($id);
        return view('customers.editCustomer', compact('data'));
    }

    public function create(Request $request)
    {
        Gate::authorize('create', Customer::class);

        $validated = $request->validate(
            [
                "name" => "required | min:3",
                "email" => "required | email",
                "address" => "required | min:10",
                "no_phone" => "required | min:10",
                "nik" => "required | max:16 | min:16",
                "foto_ktp" => "required | mimes:jpg,png,jpeg",
                "password" => "required | min:8",
            ],
            [
                'nik.min' => 'Identity number must be 16 digits.',
                'nik.max' => 'Identity number must be 16 digits.',
            ]
        );

        $customer = new Customer;
        $customer->customer_id = Str::random(10);
        $customer->customer_name = $validated['name'];
        $customer->customer_email = $validated['email'];
        $customer->customer_phone = substr_replace($validated['no_phone'], '62', 0, 1);
        $customer->customer_ktp_no = $validated['nik'];
        $customer->customer_address = $validated['address'];
        $customer->password_reset = true;
        $customer->customer_password = bcrypt($validated['password']);

        $customer->customer_ktp_picture = $validated['nik'] . '.' . $request->file('foto_ktp')->getClientOriginalExtension();
        $request->file('foto_ktp')->storeAs('public/ktp', $customer->customer_ktp_picture);
        $customer->save();

        if (Gate::allows('isSales', User::class)) {
            return Redirect()->route('entryInitSubscription')->with('success', 'Customer created successfully.');
        } else {
            return Redirect()->route('customer')->with('success', 'Customer created successfully.');
        }
    }

    public function update(Request $request, $id)
    {
        $customer = Customer::findOrFail($id);
        Gate::authorize('update', $customer);
        $validated = $request->validate(
            [
                "name" => "required | min:3",
                "email" => "required | email",
                "address" => "required | min:10",
                "no_phone" => "required | min:10",
                "nik" => "required | min:16",
                "foto_ktp" => " mimes:jpg,png,jpeg",
            ],
            [
                'nik.min' => 'Identity number must be 16 digits.',
                'nik.max' => 'Identity number must be 16 digits.',
            ]
        );

        $customer->customer_id = $customer->customer_id;
        $customer->customer_name = $validated['name'];
        $customer->customer_email = $validated['email'];
        $customer->customer_address = $validated['address'];
        $customer->customer_phone = $validated['no_phone'];
        $customer->customer_ktp_no = $validated['nik'];
        $customer->customer_password = $customer->customer_password;
        $customer->password_reset = $customer->password_reset;

        if ($request->file('foto_ktp') != null) {
            $customer->customer_ktp_picture = $validated['nik'] . '-' .  $customer->customer_id . '.' . $request->file('foto_ktp')->getClientOriginalExtension();
            Storage::delete('public/ktp/' . $customer->customer_ktp_picture);
            $request->file('foto_ktp')->storeAs('public/ktp', $customer->customer_ktp_picture);
        } else {
            $customer->customer_ktp_picture = $customer->customer_ktp_picture;
        }
        $customer->save();

        return redirect()->route('customer')->with('success', 'Customer updated successfully');
    }

    public function resetPwd(Request $request, $id)
    {
        $customer = Customer::findOrFail($id);
        Gate::authorize('update', $customer);
        $validated = $request->validate([
            "password" => "required | min:8",
        ]);

        $customer->update([
            'customer_password' => bcrypt($validated['password']),
            'password_reset' => true,
        ]);

        return redirect()->route('showCustomer', $id)->with('success', 'Reset Password successfully');
    }

    public function destroy(Customer $customer, $id)
    {
        $customer = Customer::findOrFail($id);
        Gate::authorize('delete', $customer);
        $customer->delete();

        return redirect()->route('customer')->with('success', 'Delete Customer successfully');
    }
}
