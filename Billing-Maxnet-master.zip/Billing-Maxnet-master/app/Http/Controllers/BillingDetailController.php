<?php

namespace App\Http\Controllers;

use App\Models\BillingDetail;
use App\Http\Requests\StoreBillingDetailRequest;
use App\Http\Requests\UpdateBillingDetailRequest;

class BillingDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreBillingDetailRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreBillingDetailRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\BillingDetail  $billingDetail
     * @return \Illuminate\Http\Response
     */
    public function show(BillingDetail $billingDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\BillingDetail  $billingDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(BillingDetail $billingDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateBillingDetailRequest  $request
     * @param  \App\Models\BillingDetail  $billingDetail
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateBillingDetailRequest $request, BillingDetail $billingDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\BillingDetail  $billingDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(BillingDetail $billingDetail)
    {
        //
    }
}
