<?php

namespace App\Http\Controllers;

use App\Models\SubsStatus;
use App\Http\Requests\StoreSubsStatusRequest;
use App\Http\Requests\UpdateSubsStatusRequest;

class SubsStatusController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreSubsStatusRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSubsStatusRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SubsStatus  $subsStatus
     * @return \Illuminate\Http\Response
     */
    public function show(SubsStatus $subsStatus)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SubsStatus  $subsStatus
     * @return \Illuminate\Http\Response
     */
    public function edit(SubsStatus $subsStatus)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateSubsStatusRequest  $request
     * @param  \App\Models\SubsStatus  $subsStatus
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateSubsStatusRequest $request, SubsStatus $subsStatus)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SubsStatus  $subsStatus
     * @return \Illuminate\Http\Response
     */
    public function destroy(SubsStatus $subsStatus)
    {
        //
    }
}
