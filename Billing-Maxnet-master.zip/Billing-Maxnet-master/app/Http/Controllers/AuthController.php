<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserLevel;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Gate;

class AuthController extends Controller
{
    public function login()
    {
        return view('auth.loginuser');
    }

    public function index()
    {
        Gate::authorize('isAdmin', User::class);
        $user = User::all();
        return view('auth.user', compact('user'));
    }

    public function showUser($id)
    {
        $user = User::findOrFail($id);
        Gate::authorize('showProfile', $user);
        $roles = UserLevel::findOrFail($user->user_level_id);
        return view('auth.showUser', compact('user', 'roles'));
    }

    public function invite()
    {
        Gate::authorize('isAdmin', User::class);
        $roles = UserLevel::all();
        return view('auth.inviteUser', compact('roles'));
    }

    public function invited(Request $request)
    {
        Gate::authorize('isAdmin', User::class);
        $validate = $request->validate([
            'email' => 'unique:users|required|email',
            'user_level_id' => 'required',
        ]);

        $user = new User;
        $user->user_id = Str::random(10);
        $user->email = $validate['email'];
        $user->user_level_id = $validate['user_level_id'];
        $user->save();

        return redirect()->route('showUser', $user->user_id)->with('success', 'User berhasil ditambahkan');
    }

    public function register(Request $request)
    {
        $query = $request->query('email');
        if ($query) {
            $user = User::where('email', $query)->first();
            if ($user && $user->username == null) {
                return view('auth.registerUser', compact('user'));
            } else {
                return redirect()->route('register')->with('invalid', 'Email sudah terdaftar');
            }
        } else {
            return redirect()->to('auth.registerUser')->withErrors(['invalid' => 'Email sudah terdaftar']);
        }
    }

    public function registered(Request $request)
    {
        $validate = $request->validate([
            'email' => 'required',
            'fullname' => 'required',
            'username' => 'unique:users|required|min:5',
            'password' => 'required|confirmed|min:6',
            'password_confirmation' => 'required|min:6',
        ]);
        $user = User::where('email', $request->email);

        $user->update([
            'email' => $validate['email'],
            'full_name' => Str::of($validate['fullname'])->headline(),
            'username' => Str::lower($validate['username']),
            'password' => bcrypt($validate['password']),
        ]);

        return redirect()->route('login')->with('success', 'Akun anda berhasil dibuat, silahkan login');
    }

    public function edit($id)
    {
        Gate::authorize('isAdmin', User::class);
        $user = User::where('user_id', $id)->first();
        $roles = UserLevel::all();
        return view('auth.editUser', compact('user', 'roles'));
    }

    public function update(Request $request, $id)
    {
        Gate::authorize('isAdmin', User::class);
        $validate = $request->validate([
            'full_name' => 'required',
            'username' => 'required|min:5',
            'email' => 'required',
            'user_level_id' => 'required',
        ]);

        $user = User::where('user_id', $id);
        $user->update([
            'full_name' => Str::of($validate['full_name'])->headline(),
            'username' => Str::lower($validate['username']),
            'email' => $validate['email'],
            'user_level_id' => $validate['user_level_id'],
        ]);

        return redirect()->route('user')->with('success', 'User berhasil diubah');
    }

    public function logged(Request $request)
    {
        $validate = $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        if (Auth::attempt($validate, $request->remember)) {
            $request->session()->regenerate();
            return redirect()->intended('');
        }
        return back()->with([
            'error' => 'Username atau Password Salah'
        ]);
    }

    public function resetpwd(Request $request, $id)
    {
        Gate::authorize('isAdmin', User::class);
        $validate = $request->validate([
            'password' => 'required',
        ]);
        $user = User::where('user_id', $id);
        $user->update([
            'password' => bcrypt($validate['password']),
        ]);
        return redirect()->route('showUser', $id)->with('success', 'User password berhasil diubah');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('login');
    }
}
