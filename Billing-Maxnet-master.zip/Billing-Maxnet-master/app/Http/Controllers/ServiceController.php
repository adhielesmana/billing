<?php

namespace App\Http\Controllers;

use App\Models\Service;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class ServiceController extends Controller
{
    public function index()
    {
        Gate::authorize("viewAny", Service::class);
        return view('services.service');
    }

    public function create()
    {
        Gate::authorize("create", Service::class);
        return view('services.entryService');
    }

    public function store(Request $request)
    {
        Gate::authorize("create", Service::class);
        $validated = $request->validate([
            "name" => "required | min:3",
            "desc" => "required | min:10",
            "speed" => "required | numeric | min:1",
            "price" => "required | numeric | min:1",
            "discount" => "required | numeric | min:0 | max:100",
        ]);

        $service = new Service;
        $service->serv_id = Str::random(10);
        $service->service_name = $validated['name'];
        $service->service_description = $validated['desc'];
        $service->service_speed = $validated['speed'];
        $service->service_price = $validated['price'];
        $service->service_discount = $validated['discount'];
        $service->save();

        return redirect()->route('service')->with('success', 'Service created successfully');
    }

    public function edit(Service $service, $id)
    {
        $data = Service::findOrFail($id);
        Gate::authorize("update", $data);

        return view('services.editService', compact('data'));
    }

    public function update(Request $request, $id)
    {
        $data = Service::findOrFail($id);
        Gate::authorize("update", $data);
        $validated = $request->validate([
            "name" => "required | min:3",
            "desc" => "required | min:10",
            "speed" => "required | numeric | min:1",
            "price" => "required | numeric | min:1",
            "discount" => "required | numeric | min:0 | max:100",
        ]);

        $service = Service::findOrFail($id);
        $service->serv_id = $service->serv_id;
        $service->service_name = $validated['name'];
        $service->service_description = $validated['desc'];
        $service->service_speed = $validated['speed'];
        $service->service_price = $validated['price'];
        $service->service_discount = $validated['discount'];
        $service->save();

        return redirect()->route('service')->with('success', 'Service updated successfully');
    }

    public function destroy(Service $service, $id)
    {
        $data = Service::findOrFail($id);
        Gate::authorize("delete", $data);
        $data->delete();

        return redirect()->route('service')->with('success', 'Service delete successfully');
    }
}
