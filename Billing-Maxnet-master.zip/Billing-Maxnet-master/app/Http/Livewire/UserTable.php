<?php

namespace App\Http\Livewire;

use App\Models\UserLevel;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;

class UserTable extends LivewireDatatable
{
    public $model = \App\Models\User::class;

    public function columns()
    {
        return [
            Column::name('user_id')->label('ID'),
            Column::name('full_name')->label('Nama Panjang'),
            Column::name('username')->label('Username'),
            Column::name('email')->label('Email'),
            Column::callback(['user_level_id'], function ($user_level_id) {
                $userLevel = UserLevel::findOrFail($user_level_id);
                return $userLevel ? $userLevel->user_level_name : '-';
            })->label('Role'),
            Column::callback(['user_id'], function ($user_id) {
                return view('livewire.actionUser', ['user_id' => $user_id]);
            })
        ];
    }
}
