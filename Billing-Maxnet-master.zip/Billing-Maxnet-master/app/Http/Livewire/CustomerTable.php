<?php

namespace App\Http\Livewire;

use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;

class CustomerTable extends LivewireDatatable
{

    public $model = \App\Models\Customer::class;

    public function columns()
    {
        return [
            Column::name('customer_id')->label('ID')->linkTo('customer', 6),
            Column::name('customer_name')->label('Name'),
            Column::name('customer_email')->label('Email'),
            Column::name('customer_address')->label('Address'),
            Column::name('customer_phone')->label('Phone'),
            Column::name('customer_ktp_no')->label('Ktp No'),
            Column::name('created_at')->label('Join Date'),
            Column::name('customer_ktp_picture')->label('Ktp Picture'),
            Column::callback(['customer_id'], function ($customer_id) {
                return view('livewire.actionCustomer', ['customer_id' => $customer_id]);
            })
        ];
    }
}
