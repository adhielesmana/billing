<?php

namespace App\Http\Livewire;

use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;

class ServiceTable extends LivewireDatatable
{

    public $model = \App\Models\Service::class;

    public function columns()
    {
        return [
            Column::name('serv_id')->label('ID'),
            Column::name('service_name')->label('Name'),
            Column::name('service_description')->label('Description'),
            Column::name('service_speed')->label('Speed (Mbps)'),
            Column::name('service_price')->label('Price@Month'),
            Column::name('service_discount')->label('Discount (%)'),
            Column::callback(['serv_id'], function ($serv_id) {
                return view('livewire.actionService', ['serv_id' => $serv_id]);
            })
        ];
    }
}
