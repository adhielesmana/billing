<?php

namespace App\Http\Livewire;

use App\Models\SiteType;
use App\Models\Site;
use Carbon\Carbon;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\NumberColumn;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;

class SiteTable extends LivewireDatatable
{

    public function builder()
    {
        return Site::query()->leftJoin('site_types', 'sites.site_type_id', '=', 'site_types.site_type_id')->select('sites.*', 'site_types.site_type_name');
    }

    public function columns()
    {
        return [
            Column::callback(['site_name', 'site_id'], function ($site_name, $site_id) {
                $site = new $this->model;
                $site = $site->find($site_id);
                $site_parent = $site->site_parent;
                $parent = $site->find($site_parent);
                if ($parent === null) {
                    return $site_name;
                }
                return $site_name . "=>" . $parent->site_name;
            })->label('Site Name')->unwrap(),
            Column::name('site_address')->label('Site Address'),
            Column::name('site_types.site_type_name')->label('Type Site')->filterable(SiteType::pluck('site_type_name')),
            // Column::name('site_parent')->label('Site Parent'),
            Column::callback(['site_parent'], function ($site_parent) {
                $site = new $this->model;
                $parent = $site->find($site_parent);
                if ($parent === null) {
                    return '-';
                } else {
                    $grandParent = $site->find($parent->site_parent);
                    if ($grandParent === null) {
                        return $parent->site_name;
                    }
                    return $parent->site_name . "=>" . $grandParent->site_name;
                }
            })->label('Site Parent')->unwrap(),
            NumberColumn::name('site_port_capacity')->label('Port Capacity')->filterable(),
            NumberColumn::callback(['site_port_capacity', 'site_id', 'site_types.site_type_name'], function ($site_port_capacity, $site_id, $site_type_name) {
                // dd($site_type_name);
                $site = new $this->model;
                if ($site_type_name == 'ODP') {
                    $site_port_capacity = 0;
                    return $site_port_capacity;
                }else{
                    $site_parent = $site->where('site_parent', $site_id)->count();
                    $site_port_available = $site_port_capacity - $site_parent;
                    return $site_port_available;
                }
            })->label('Port Available')->filterable(),
            Column::name('site_description')->label('Site Description'),
            Column::callback(['updated_at'], function ($updated_at) {
                return Carbon::parse($updated_at)->format('Y-m-d H:i') . ' WIB';
            })->sortBy('updated_at')->label('Last Update'),
            Column::callback(['site_id'], function ($site_id) {
                return view('livewire.actionSite', ['site_id' => $site_id]);
            })
        ];
    }
}
