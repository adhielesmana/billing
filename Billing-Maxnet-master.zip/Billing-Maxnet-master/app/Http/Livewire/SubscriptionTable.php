<?php

namespace App\Http\Livewire;

use App\Models\Customer;
use App\Models\Service;
use App\Models\User;

use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use Illuminate\Support\Facades\Gate;

class SubscriptionTable extends LivewireDatatable
{

    public $model = \App\Models\Subscription::class;

    public function builder()
    {
        if (Gate::allows('isSales', User::class)) {
            return \App\Models\Subscription::query()->where('created_by', auth()->user()->user_id)->whereNot('subscription_status', 'ACTIVE');
        } elseif (Gate::allows('isTeknisi', User::class)) {
            return \App\Models\Subscription::query()->where('subscription_status', ['PROCEED', 'INSTALLED']);
        } else {
            return \App\Models\Subscription::query();
        }
    }

    public function columns()
    {
        return [
            Column::name('subscription_id')->label('ID'),
            Column::callback(['customer_id'], function ($customer_id) {
                $customer = Customer::find($customer_id);
                return $customer ? $customer->customer_name . ' - ' . $customer->customer_ktp_no : '-';
            })->label('Name/NIK'),
            Column::callback(['serv_id'], function ($serv_id) {
                $service = Service::find($serv_id);
                return $service ? strtoupper($service->service_name) . ' (' . $service->service_speed . ' Mbps)' : '-';
            })->label('Service'),
            Column::name('subscription_address')->label('Address'),
            Column::callback(['subscription_start_date'], function ($subscription_start_date) {
                if ($subscription_start_date) {
                    return $subscription_start_date;
                } else {
                    return '-';
                }
            })->label('Start Date'),
            Column::name('created_at')->label('Created At'),
            Column::name('subscription_status')->label('Status'),
            Column::callback(['subscription_id'], function ($subscription_id) {
                return view('livewire.actionSubscription', ['subscription_id' => $subscription_id]);
            })
        ];
    }
}
