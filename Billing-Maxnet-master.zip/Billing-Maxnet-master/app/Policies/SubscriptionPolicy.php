<?php

namespace App\Policies;

use App\Models\Subscription;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class SubscriptionPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewAny(User $user)
    {
        return $user->user_level_id == User::IS_ADMIN || $user->user_level_id == User::IS_NOC || $user->user_level_id == User::IS_SALES || $user->user_level_id == User::IS_TEKNISI;;
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Subscription  $subscription
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function view(User $user, Subscription $subscription)
    {
        return $user->user_level_id == User::IS_ADMIN || $user->user_level_id == User::IS_NOC || $user->user_level_id == User::IS_SALES;
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function createSales(User $user)
    {
        return $user->user_level_id == User::IS_NOC || $user->user_level_id == User::IS_SALES;
    }

    public function createTeknisi(User $user)
    {
        return $user->user_level_id == User::IS_TEKNISI;
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Subscription  $subscription
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function update(User $user, Subscription $subscription)
    {
        return  $user->user_level_id == User::IS_NOC;
    }

    public function updateTeknisi(User $user, Subscription $subscription)
    {
        return  $user->user_level_id == User::IS_NOC || $user->user_level_id == User::IS_TEKNISI;
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Subscription  $subscription
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function delete(User $user, Subscription $subscription)
    {
        return $user->user_level_id == User::IS_NOC;
    }
}
