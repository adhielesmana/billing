<?php

namespace App\Policies;

use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Facades\Auth;

class UserPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function isAdmin(User $user)
    {
        return $user->user_level_id == User::IS_ADMIN;
    }
    public function isSales(User $user)
    {
        return $user->user_level_id == User::IS_SALES;
    }
    public function isNoc(User $user)
    {
        return $user->user_level_id == User::IS_NOC;
    }
    public function isTeknisi(User $user)
    {
        return $user->user_level_id == User::IS_TEKNISI;
    }
    public function showProfile(User $userAuth, User $model)
    {
        // dd($userAuth->user_id, $model->user_id);
        return $userAuth->user_id === $model->user_id || $userAuth->user_level_id == User::IS_ADMIN;
    }
}
