<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Subscription extends Model
{
    use HasFactory;

    protected $table = 'subscriptions';
    protected $primaryKey = 'subscription_id';
    protected $with = ['customer', 'service'];
    protected $fillable = [
        'subscription_id',
        'subscription_password',
        'customer_id',
        'serv_id',
        'created_by',
        'subscription_address',
        'subscription_start_date',
        'subscription_billing_cycle',
        'subscription_price',
        'subscription_status',
        'subscription_maps',
        'subscription_home_photo',
        'subscription_form_scan',
        'subscription_description',
        'cpe_type',
        'cpe_serial',
        'cpe_picture',
        'cpe_site',
        'group'
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'customer_id', 'customer_id');
    }

    public function service()
    {
        return $this->belongsTo(Service::class, 'serv_id', 'serv_id');
    }

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->subscription_id = $model->generateSubscriptionId();
        });
    }

    // Awalnya Kurawal Dua
    public function generateSubscriptionId()
    {
        $year = substr(date('Y'), -2); // Mengambil digit tahun terakhir
        $month = date('m'); // Mengambil bulan saat ini
        $lastRecord = Subscription::orderBy('created_at', 'desc')->first();

        if ($lastRecord && Carbon::parse($lastRecord->created_at)->format('Ym') === date('Ym')) {
            // Jika ada record terakhir dengan bulan yang sama, increment berdasarkan record terakhir
            $increment = str_pad($lastRecord->getIncrementNumber() + 1, 5, '0', STR_PAD_LEFT);
        } else {
            // Jika tidak ada record terakhir atau bulan berbeda, reset increment menjadi 1
            $increment = '00001';
        }

        return $year . $month . $this->group . $increment;
    }

    public function getIncrementNumber()
    {
        return intval(substr($this->subscription_id, -5));
    }
}
