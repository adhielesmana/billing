<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SiteType extends Model
{
    use HasFactory;

    protected $primaryKey = 'site_type_id';
    public $incrementing = false;
    protected $fillable = [
        'site_type_name',
        'site_type_description',
    ];

    
    public function sites()
    {
        return $this->hasMany(Site::class, 'site_type_id', 'site_type_id');
    }
}
