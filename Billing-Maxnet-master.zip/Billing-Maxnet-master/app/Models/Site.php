<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Site extends Model
{
    use HasFactory;

    protected $primaryKey = 'site_id';
    public $incrementing = false;
    protected $fillable = [
        'site_name',
        'site_address',
        'site_parent',
        'site_type',
        'site_picture',
        'site_location_maps',
        'site_description',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->site_id = $model->generateSiteId();
        });
    }

    // Awalnya Kurawal Dua
    public function generateSiteId()
    {
        $year = substr(date('Y'), -2); // Mengambil digit tahun terakhir
        $month = date('m'); // Mengambil bulan saat ini
        $lastRecord = Site::orderBy('created_at', 'desc')->first();

        if ($lastRecord && Carbon::parse($lastRecord->created_at)->format('Ym') === date('Ym')) {
            // Jika ada record terakhir dengan bulan yang sama, increment berdasarkan record terakhir
            $increment = str_pad($lastRecord->getIncrementNumber() + 1, 4, '0', STR_PAD_LEFT);
        } else {
            // Jika tidak ada record terakhir atau bulan berbeda, reset increment menjadi 1
            $increment = '0001';
        }

        return $year . $month . $increment;
    }

    public function getIncrementNumber()
    {
        return intval(substr($this->site_id, -4));
    }

    public function siteType()
    {
        return $this->belongsTo(SiteType::class, 'site_type_id', "site_type_id");
    }
}
