<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Customer extends Model
{
    use HasFactory;

    protected $table = 'customers';
    protected $primaryKey = 'customer_id';
    public $incrementing = false;
    protected $fillable = [
        'customer_id',
        'customer_password',
        'customer_name',
        'customer_email',
        'customer_phone',
        'customer_ktp_no',
        'customer_ktp_picture',
    ];

    public function subscription()
    {
        return $this->hasMany(Subscription::class, 'customer_id', 'customer_id');
    }

    public function service()
    {
        return $this->hasManyThrough((Service::class), (Subscription::class), 'customer_id', 'serv_id', 'customer_id', 'serv_id');
    }

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->customer_id = $model->generateCustomerId();
        });
    }

    // Awalnya Kurawal Dua
    public function generateCustomerId()
    {
        $year = substr(date('Y'), -2); // Mengambil digit tahun terakhir
        $month = date('m'); // Mengambil bulan saat ini
        $lastRecord = Customer::orderBy('created_at', 'desc')->first();

        if ($lastRecord && Carbon::parse($lastRecord->created_at)->format('Ym') === date('Ym')) {
            // Jika ada record terakhir dengan bulan yang sama, increment berdasarkan record terakhir
            $increment = str_pad($lastRecord->getIncrementNumber() + 1, 5, '0', STR_PAD_LEFT);
        } else {
            // Jika tidak ada record terakhir atau bulan berbeda, reset increment menjadi 1
            $increment = '00001';
        }

        return $year . $month . $increment;
    }

    public function getIncrementNumber()
    {
        return intval(substr($this->customer_id, -5));
    }
}
